# Safe AI Way - stap B: de organisatiecode voor Chrome en Edge.
#
# Uitrollen als Intune-platformscript, met:
#   Run this script using the logged on credentials : Nee
#   Run script in 64 bit PowerShell host            : Ja
#
# Dit script raakt ALLEEN de eigen sleutel van de extensie
# (...\3rdparty\extensions\<id>\policy). Het komt niet aan je overige
# Chrome- of Edge-beleid.
#
# Stap A (de extensie installeren) doe je in de instellingencatalogus.

$ErrorActionPreference = "Stop"

$browsers = @(
  @{ Naam = "Chrome"; Sleutel = "HKLM:\SOFTWARE\Policies\Google\Chrome";    Id = "lkgpjlchmogakdjajobeefljcnbkkfjn" },
  @{ Naam = "Edge";   Sleutel = "HKLM:\SOFTWARE\Policies\Microsoft\Edge";   Id = "dlgppainmldonhgfbfnhccogkpbhjdoc" }
)

# Het script zet beide browsers. Rol je er maar één uit, dan is dat onschadelijk:
# een registersleutel voor een browser die er niet staat, doet niets.
$mislukt = 0
foreach ($b in $browsers) {
  # Elke browser apart, zodat een probleem bij de ene de andere niet meesleept.
  try {
    $pad = Join-Path $b.Sleutel "3rdparty\extensions\$($b.Id)\policy"

    # New-Item -Force op een BESTAANDE sleutel maakt die leeg. Alleen aanmaken
    # wanneer ze er nog niet is.
    if (-not (Test-Path $pad)) { New-Item -Path $pad -Force | Out-Null }

    New-ItemProperty -Path $pad -Name enrollmentToken  -Value "org_REMBERT02" -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $pad -Name deploymentFlavor -Value "school"        -PropertyType String -Force | Out-Null
    Write-Output "$($b.Naam): organisatiecode gezet."
  } catch {
    $mislukt++
    Write-Output "$($b.Naam): MISLUKT - $_"
  }
}
if ($mislukt -gt 0) { exit 1 }
