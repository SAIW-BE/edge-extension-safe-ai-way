# Safe AI Way - Firefox, detectie voor een Intune-remediatie.
#
#   Run this script using the logged on credentials : Nee
#   Run script in 64 bit PowerShell host            : Ja
#
# Exit 0 = in orde, exit 1 = herstellen.

# Dit veronderstelt een standaardinstallatiepad. Staat Firefox ergens anders,
# bijvoorbeeld op een andere schijf, vul dat pad hier dan aan.
$mappen = @(@(
  "$env:SystemDrive\Program Files\Mozilla Firefox",
  "$env:SystemDrive\Program Files (x86)\Mozilla Firefox"
) | Select-Object -Unique | Where-Object { Test-Path $_ })

if ($mappen.Count -eq 0) { exit 0 }   # Firefox staat er niet, niets te doen

foreach ($map in $mappen) {
  $pad = Join-Path $map "distribution\policies.json"
  if (-not (Test-Path $pad)) { exit 1 }
  # Toets de BETEKENIS, niet of de tekst er ergens in staat: een bestand met een
  # gebroken regel bevat de code wel en is toch onbruikbaar.
  try { $p = (Get-Content $pad -Raw | ConvertFrom-Json).policies } catch { exit 1 }
  if ($p.'3rdparty'.Extensions.'info@safeaiway.com'.enrollmentToken -ne "org_REMBERT02") { exit 1 }
  if (-not $p.ExtensionSettings.'info@safeaiway.com') { exit 1 }
}
exit 0
