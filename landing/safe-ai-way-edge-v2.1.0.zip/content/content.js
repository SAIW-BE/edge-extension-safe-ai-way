"use strict";(()=>{var ri=Object.defineProperty;var _=(e,t)=>()=>(e&&(t=e(e=0)),t);var ci=(e,t)=>{for(var n in t)ri(e,n,{get:t[n],enumerable:!0})};function $(){return F?.storage?.local??F?.storage?.sync}function pn(){return new Promise(e=>{$().get(ie,t=>{let n=Object.assign({},_e,t?.[ie]||{});e(n)})})}function gn(){return new Promise(e=>{try{$().get(Ae,t=>{e(t?.[Ae]||null)})}catch{e(null)}})}function hn(e,t){F?.runtime?.onMessage?.addListener?.(n=>{n?.type==="SETTINGS_UPDATED"&&n.settings&&e(n.settings),n?.type==="LICENSE_STATUS_CHANGED"&&n.status&&t&&t(n.status)}),F?.storage?.onChanged?.addListener?.((n,o)=>{if((o==="sync"||o==="local")&&n?.[ie]?.newValue){let i=Object.assign({},_e,n[ie].newValue);e(i)}(o==="sync"||o==="local")&&n?.[Ae]?.newValue&&t&&t(n[Ae].newValue)})}var F,ie,_e,Ae,dt=_(()=>{"use strict";F=(typeof browser<"u"?browser:window.chrome)??{},ie="sanitize_settings",_e={enabled:!0,profile:"learnmate",mask_email:!0,mask_phone:!0,mask_cc:!0,mask_iban:!0,mask_natid:!0,mask_address:!0,mask_dob_age:!0,mask_children:!0,mask_name:!0,mask_health:!0,mask_crisis:!0,images_policy:"warn",pdfs_policy:"warn",office_policy:"warn",visual_replace_on_send:!0,block_jailbreak:!0,crisis_detect:!0,whitelist:[],blocklist:[],redirect_url:"https://www.safeaiway.com/",analytics_enabled:!0};Ae="license_status"});function li(){return"ai_safety_badge_pos_v1"}function Ie(){if(document.getElementById(`${A}-style`))return;let e=document.createElement("style");e.id=`${A}-style`,e.textContent=`
    #${A} {
      position: fixed;
      inset: auto auto 16px 16px; /* bottom-left default */
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 8px 12px;
      border-radius: 999px;
      border: 2px solid transparent;
      background: #402BBC;
      color: #fff;
      font-family: system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif;
      font-size: 13px;
      font-weight: 700;
      box-shadow: 0 2px 10px rgba(0,0,0,.15);
      user-select: none;
      cursor: grab;
      z-index: 2147483645;
      transition: box-shadow .15s, transform .1s, background .15s, border-color .15s;
    }
    #${A}.dragging { cursor: grabbing; transform: scale(0.98); box-shadow: 0 10px 28px rgba(0,0,0,0.25); }
    #${A} svg {
      width: 28px;
      height: 28px;
      flex-shrink: 0;
      fill: #fff;
    }
    /* Profiel kleuren - Zichtbare profielen */
    #${A}.profile-learnmate {
      border-color: #402BBC;
      background: linear-gradient(90deg, #9B8EED 0%, #6B63EA 50.96%, #402BBC 100%)
    }
    #${A}.profile-safemate {
      background: linear-gradient(90deg, #DF8FDF 0%, #B235B2 50.96%, #8C168C 100%);
      border-color: #8C168C;
    }
    #${A}.profile-classmate {
      background: #1867A7;
      border-color: #1867A7;
    }
    /* Profiel kleuren - Verborgen profielen (backwards compatibility) */
    #${A}.profile-blokkeren {
      background: linear-gradient(90deg, #DF8FDF 0%, #B235B2 50.96%, #8C168C 100%);
      border-color: #8C168C;
    }
    #${A}.profile-aangepast {
      background: #1867A7;
      border-color: #1867A7;
    }
    @media (max-width: 480px) {
      #${A} { padding: 8px 12px; }
    }

    /* Notification popup styles */
    .ai-safety-notification {
      position: fixed;
      max-width: 320px;
      padding: 16px 40px 16px 20px;
      border-radius: 16px;
      border: 2px solid;
      font-family: system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif;
      box-shadow: 0 8px 24px rgba(0,0,0,0.15);
      z-index: 2147483646;
      animation: slideInUp 0.3s ease-out;
      pointer-events: auto;
      transition: transform 0.3s ease-out, opacity 0.2s ease-out;
    }
    /* Overflow indicator */
    .ai-safety-notification-overflow {
      position: fixed;
      max-width: 320px;
      padding: 12px 20px;
      border-radius: 12px;
      border: 2px solid;
      font-family: system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
      z-index: 2147483645;
      pointer-events: none;
      font-size: 13px;
      font-weight: 600;
      text-align: center;
      color: #6b7280;
      background: rgba(255, 255, 255, 0.95);
      backdrop-filter: blur(10px);
      border-color: #e5e7eb;
    }
    /* Close button */
    .ai-safety-notification-close {
      position: absolute;
      top: 12px;
      right: 12px;
      width: 20px;
      height: 20px;
      border: none;
      background: transparent;
      cursor: pointer;
      padding: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 4px;
      transition: background-color 0.2s;
      color: #9ca3af;
      font-size: 18px;
      line-height: 1;
      font-weight: 600;
    }
    .ai-safety-notification-close:hover {
      background-color: rgba(0, 0, 0, 0.05);
      color: #6b7280;
    }
    .ai-safety-notification-close:active {
      background-color: rgba(0, 0, 0, 0.1);
    }
    @keyframes slideInUp {
      from {
        opacity: 0;
        transform: translateY(10px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
    @keyframes slideOutDown {
      from {
        opacity: 1;
        transform: translateY(0);
      }
      to {
        opacity: 0;
        transform: translateY(10px);
      }
    }
    .ai-safety-notification.hiding {
      animation: slideOutDown 0.3s ease-in forwards;
    }
    .ai-safety-notification-content {
      margin: 0;
      color: #1f2937;
      font-size: 14px;
      line-height: 1.5;
    }
    .ai-safety-notification-content strong {
      font-weight: 700;
    }
    .ai-safety-notification-detail {
      margin: 8px 0 0 0;
      color: #6b7280;
      font-size: 12px;
      line-height: 1.4;
    }
    /* Profile-specific notification colors - Zichtbare profielen */
    .ai-safety-notification.profile-learnmate {
      background: #F5F4FF;
      border-color: #C6BDFF;
    }
    .ai-safety-notification.profile-learnmate::after {
      border-top-color: #C6BDFF;
    }
    .ai-safety-notification.profile-learnmate .ai-safety-notification-content strong {
      color: #402BBC;
    }
    .ai-safety-notification.profile-safemate {
      background: #FFF8FF;
      border-color: #FBDCFB;
    }
    .ai-safety-notification.profile-safemate::after {
      border-top-color: #FBDCFB;
    }
    .ai-safety-notification.profile-safemate .ai-safety-notification-content strong {
      color: #8C168C;
    }
    .ai-safety-notification.profile-classmate {
      background: #F4FAFF;
      border-color: #D7EEFF;
    }
    .ai-safety-notification.profile-classmate::after {
      border-top-color: #D7EEFF;
    }
    .ai-safety-notification.profile-classmate .ai-safety-notification-content strong {
      color: #1867A7;
    }
    /* Profile-specific notification colors - Verborgen profielen */
    .ai-safety-notification.profile-blokkeren {
      background: #FFF8FF;
      border-color: #FBDCFB;
    }
    .ai-safety-notification.profile-blokkeren::after {
      border-top-color: #FBDCFB;
    }
    .ai-safety-notification.profile-blokkeren .ai-safety-notification-content strong {
      color: #8C168C;
    }
    .ai-safety-notification.profile-aangepast {
      background: #F4FAFF;
      border-color: #D7EEFF;
    }
    .ai-safety-notification.profile-aangepast::after {
      border-top-color: #D7EEFF;
    }
    .ai-safety-notification.profile-aangepast .ai-safety-notification-content strong {
      color: #1867A7;
    }

    /* AI Website notification with action button */
    .ai-safety-notification-actions {
      margin-top: 12px;
      display: flex;
      gap: 8px;
    }
    .ai-safety-profile-switch-btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      padding: 8px 14px;
      border-radius: 999px;
      border: 2px solid transparent;
      font-family: 'Montserrat', system-ui, -apple-system, Segoe UI, Roboto, sans-serif;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      transition: transform 0.15s, box-shadow 0.15s;
      background: linear-gradient(90deg, #DF8FDF 0%, #B235B2 50.96%, #8C168C 100%);
      border-color: #8C168C;
      color: #fff;
    }
    .ai-safety-profile-switch-btn:hover {
      transform: scale(1.02);
      box-shadow: 0 4px 12px rgba(140, 22, 140, 0.3);
    }
    .ai-safety-profile-switch-btn:active {
      transform: scale(0.98);
    }
    .ai-safety-profile-switch-btn svg {
      width: 18px;
      height: 18px;
      fill: #fff;
      flex-shrink: 0;
    }

    /* LearnMate "Verbergen" button */
    .ai-safety-hide-btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      padding: 8px 14px;
      border-radius: 999px;
      border: 2px solid transparent;
      font-family: system-ui, -apple-system, Segoe UI, Roboto, sans-serif;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      transition: transform 0.15s, box-shadow 0.15s;
      background: linear-gradient(90deg, #9B8EED 0%, #6B63EA 50.96%, #402BBC 100%);
      border-color: #402BBC;
      color: #fff;
    }
    .ai-safety-hide-btn:hover {
      transform: scale(1.02);
      box-shadow: 0 4px 12px rgba(64, 43, 188, 0.3);
    }
    .ai-safety-hide-btn:active {
      transform: scale(0.98);
    }
    .ai-safety-hide-btn svg {
      width: 16px;
      height: 16px;
      fill: #fff;
      flex-shrink: 0;
    }
  `,document.documentElement.appendChild(e)}function ae(){return{w:Math.max(320,window.innerWidth||0),h:Math.max(320,window.innerHeight||0)}}function B(e,t,n){return Math.min(Math.max(e,t),n)}function bn(e,t,n,o){let{w:i,h:a}=ae(),s=e.getBoundingClientRect(),r=B(n,0,i-s.width),c=B(o,0,a-s.height),l={leftPct:r/i,topPct:c/a};q!==null&&window.clearTimeout(q),q=window.setTimeout(()=>{try{let d=$();d&&d.set({[t]:l},()=>{})}catch{}q=null},50)}function di(e,t){try{let n=$();if(!n)return;n.get(t,o=>{if(chrome?.runtime?.lastError)return;let i=o?.[t];if(!i||typeof i!="object")return;let{w:a,h:s}=ae(),r=e.getBoundingClientRect(),c=B(Math.round((i.leftPct??0)*a),0,a-r.width),l=B(Math.round((i.topPct??0)*s),0,s-r.height);e.style.left=`${c}px`,e.style.top=`${l}px`,e.style.right="auto",e.style.bottom="auto"})}catch{}}function ui(e,t){let n=0,o=0,i=0,a=0,s=!1,r=(m,y)=>{s=!0,e.classList.add("dragging");let x=e.getBoundingClientRect();n=m,o=y,i=x.left,a=x.top,document.body.style.userSelect="none"},c=(m,y)=>{if(!s)return;let x=m-n,h=y-o,{w,h:S}=ae(),D=e.getBoundingClientRect(),he=B(i+x,0,w-D.width),K=B(a+h,0,S-D.height);e.style.left=`${he}px`,e.style.top=`${K}px`,e.style.right="auto",e.style.bottom="auto"},l=()=>{if(!s)return;s=!1,e.classList.remove("dragging"),document.body.style.userSelect="";let m=e.getBoundingClientRect();bn(e,t,m.left,m.top)},d=m=>{m.preventDefault(),c(m.clientX,m.clientY)},u=m=>{m.preventDefault(),window.removeEventListener("mousemove",d,!0),window.removeEventListener("mouseup",u,!0),l()};e.addEventListener("mousedown",m=>{m.button===0&&(m.preventDefault(),r(m.clientX,m.clientY),window.addEventListener("mousemove",d,!0),window.addEventListener("mouseup",u,!0))});let f=m=>{if(m.touches.length!==1)return;let y=m.touches[0];m.preventDefault(),c(y.clientX,y.clientY)},p=m=>{m.preventDefault(),window.removeEventListener("touchmove",f,!0),window.removeEventListener("touchend",p,!0),window.removeEventListener("touchcancel",p,!0),l()};e.addEventListener("touchstart",m=>{if(m.touches.length!==1)return;let y=m.touches[0];m.preventDefault(),r(y.clientX,y.clientY),window.addEventListener("touchmove",f,{passive:!1,capture:!0}),window.addEventListener("touchend",p,{passive:!1,capture:!0}),window.addEventListener("touchcancel",p,{passive:!1,capture:!0})},{passive:!1}),window.addEventListener("resize",()=>{let m=e.getBoundingClientRect(),{w:y,h:x}=ae(),h=B(m.left,0,y-m.width),w=B(m.top,0,x-m.height);e.style.left=`${h}px`,e.style.top=`${w}px`,e.style.right="auto",e.style.bottom="auto",bn(e,t,h,w)})}function wn(e){let t='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640"><!--!Font Awesome Pro v7.1.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2026 Fonticons, Inc.--><path d="M480 256C480 298.7 463.3 337.4 436.1 366.1C416.2 387 395.7 414.8 387.6 448L252.4 448C244.3 414.7 223.8 387 203.9 366.1C176.7 337.4 160 298.7 160 256C160 167.6 231.6 96 320 96C408.4 96 480 167.6 480 256zM256 480L384 480L384 496C384 522.5 362.5 544 336 544L304 544C277.5 544 256 522.5 256 496L256 480zM416 477.7C416 443.4 435.7 413 459.3 388.1C492 353.7 512 307.2 512 256C512 150 426 64 320 64C214 64 128 150 128 256C128 307.2 148 353.7 180.7 388.1C204.3 413 224 443.4 224 477.7L224 496C224 540.2 259.8 576 304 576L336 576C380.2 576 416 540.2 416 496L416 477.7zM304 176C312.8 176 320 168.8 320 160C320 151.2 312.8 144 304 144C251 144 208 187 208 240C208 248.8 215.2 256 224 256C232.8 256 240 248.8 240 240C240 204.7 268.7 176 304 176zM40.9 82.7C33.5 77.8 23.6 79.8 18.7 87.1C13.8 94.4 15.8 104.4 23.1 109.3L71.1 141.3C78.5 146.2 88.4 144.2 93.3 136.9C98.2 129.6 96.2 119.6 88.9 114.7L40.9 82.7zM616.9 109.3C624.3 104.4 626.2 94.5 621.3 87.1C616.4 79.7 606.5 77.8 599.1 82.7L551.1 114.7C543.7 119.6 541.8 129.5 546.7 136.9C551.6 144.3 561.5 146.2 568.9 141.3L616.9 109.3zM16 240C7.2 240 0 247.2 0 256C0 264.8 7.2 272 16 272L64 272C72.8 272 80 264.8 80 256C80 247.2 72.8 240 64 240L16 240zM576 240C567.2 240 560 247.2 560 256C560 264.8 567.2 272 576 272L624 272C632.8 272 640 264.8 640 256C640 247.2 632.8 240 624 240L576 240zM88.9 397.3C96.3 392.4 98.2 382.5 93.3 375.1C88.4 367.7 78.5 365.8 71.1 370.7L23.1 402.7C15.7 407.6 13.8 417.5 18.7 424.9C23.6 432.3 33.5 434.2 40.9 429.3L88.9 397.3zM568.9 370.7C561.5 365.8 551.6 367.8 546.7 375.1C541.8 382.4 543.8 392.4 551.1 397.3L599.1 429.3C606.5 434.2 616.4 432.2 621.3 424.9C626.2 417.6 624.2 407.6 616.9 402.7L568.9 370.7z"/></svg>',n='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640"><path d="M237.3 66.9C247.6 56.1 261.2 48 278 48C290.9 48 302.4 53 310.7 57C314.6 58.8 317.8 59.7 320 59.7C322.2 59.7 325.4 58.9 329.3 57C337.6 53 349.1 48 362 48C378.8 48 392.4 56.2 402.7 66.9C412.9 77.5 420.7 91.5 426.7 105.7C436.5 128.7 442.6 154.9 445.9 176L479.9 176C488.7 176 495.9 183.2 495.9 192C495.9 200.8 488.7 208 479.9 208L447.9 208L447.9 240C447.9 257 444.6 273.2 438.6 288L479.9 288C485.3 288 490.2 290.7 493.2 295.1C496.2 299.5 496.7 305.2 494.7 310.1L460.3 392.8C483.9 407.4 503.3 429.4 517.4 454.2C534.1 483.7 544 518.4 544 551.9L544 559.9C544 568.7 536.8 575.9 528 575.9C519.2 575.9 512 568.7 512 559.9L512 551.9C512 524.4 503.8 495.1 489.6 469.9C475.3 444.7 455.5 424.7 433.3 414.4C425.5 410.8 422 401.7 425.3 393.7L456.1 319.9L420 319.9C396.5 349.2 360.5 367.9 320.1 367.9C279.7 367.9 243.6 349.2 220.2 319.9L184.1 319.9L214.9 393.7C218.2 401.6 214.7 410.7 206.9 414.4C184.6 424.7 164.9 444.7 150.6 469.9C136.3 495 128.2 524.3 128.2 551.9L128.2 559.9C128.2 568.7 121 575.9 112.2 575.9C103.4 575.9 96 568.8 96 560L96 552C96 518.5 105.8 483.8 122.6 454.3C136.7 429.4 156.1 407.4 179.7 392.9L145.2 310.2C143.1 305.3 143.7 299.6 146.7 295.2C149.7 290.8 154.7 288.1 160 288.1L201.3 288.1C195.3 273.3 192 257.1 192 240.1L192 208.1L160 208.1C151.2 208.1 144 200.9 144 192.1C144 183.3 151.2 176.1 160 176.1L194 176.1C197.3 155.1 203.5 128.8 213.2 105.8C219.2 91.5 227.1 77.6 237.2 67zM226.4 176L413.5 176C410.4 157.9 405 136.5 397.3 118.3C392 105.9 386 95.8 379.6 89.1C373.3 82.5 367.6 80 362 80C356.8 80 351 82 343 85.9C337 88.8 328.8 91.7 320 91.7C311.2 91.7 303 88.8 297 85.9C289 82.1 283.2 80 278 80C272.4 80 266.6 82.5 260.4 89.1C254 95.8 248 105.9 242.7 118.3C234.9 136.6 229.6 157.9 226.5 176zM228.2 268.4C240.4 307.6 276.9 336 320 336C363.1 336 399.6 307.6 411.7 268.4C405.6 270.7 398.9 272 392 272L364.8 272C346.8 272 330.3 263.4 320 249.6C309.6 263.5 293.1 272 275.2 272L248 272C241.1 272 234.4 270.7 228.3 268.4zM416 216L416 208L336.9 208L342.1 223.6C345.4 233.4 354.5 240 364.9 240L392.1 240C405.4 240 416.1 229.3 416.1 216zM303.1 208L224 208L224 216C224 229.3 234.7 240 248 240L275.2 240C285.5 240 294.7 233.4 298 223.6L303.2 208zM352 432L342.2 432L383.2 554.9C384.8 559.8 384 565.1 381 569.3C378 573.5 373.2 575.9 368 575.9L272 575.9C266.9 575.9 262 573.4 259 569.3C256 565.2 255.2 559.8 256.8 554.9L297.8 432L288 432C279.2 432 272 424.8 272 416C272 407.2 279.2 400 288 400L352 400C360.8 400 368 407.2 368 416C368 424.8 360.8 432 352 432zM320 466.6L294.2 544L345.8 544L320 466.6z"/></svg>',o='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640"><path d="M160.4 192C160.4 139 203.4 96 256.4 96C309.4 96 352.4 139 352.4 192C352.4 245 309.4 288 256.4 288C203.4 288 160.4 245 160.4 192zM384.4 192C384.4 121.3 327.1 64 256.4 64C185.7 64 128.4 121.3 128.4 192C128.4 262.7 185.7 320 256.4 320C327.1 320 384.4 262.7 384.4 192zM64.4 544C64.4 464.5 128.9 400 208.4 400L304.4 400C322.3 400 339.4 403.3 355.2 409.2L379.6 384.8C356.7 374 331.3 368 304.4 368L208.4 368C111.2 368 32.4 446.8 32.4 544L32.4 560C32.4 568.8 39.6 576 48.4 576C57.2 576 64.4 568.8 64.4 560L64.4 544zM373.5 504.1L475.7 401.9L526.4 452.6L424.2 554.8C419.5 559.5 413.4 562.6 406.8 563.7L356 572.2L364.5 521.4C365.6 514.8 368.7 508.8 373.4 504zM498.3 379.3L519 358.6C533 344.6 555.7 344.6 569.7 358.6C583.7 372.6 583.7 395.3 569.7 409.3L549 430L498.3 379.3zM333 516.2L320.6 590.8C319 600.6 327.8 609.4 337.6 607.8L412.2 595.4C425.4 593.2 437.5 587 446.9 577.5L592.4 432C618.9 405.5 618.9 362.5 592.4 336C565.9 309.5 522.9 309.5 496.4 336L350.9 481.5C341.5 490.9 335.2 503.1 333 516.2z"/></svg>';return{learnmate:t,safemate:n,classmate:'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640"><!--!Font Awesome Pro v7.1.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2026 Fonticons, Inc.--><path d="M512 96L128 96C110.3 96 96 110.3 96 128L96 272C84.9 272 74.1 273.6 64 276.6L64 128C64 92.7 92.7 64 128 64L512 64C547.3 64 576 92.7 576 128L576 276.6C565.9 273.6 555.1 272 544 272L544 128C544 110.3 529.7 96 512 96zM96 416C113.7 416 128 401.7 128 384C128 366.3 113.7 352 96 352C78.3 352 64 366.3 64 384C64 401.7 78.3 416 96 416zM96 320C131.3 320 160 348.7 160 384C160 419.3 131.3 448 96 448C60.7 448 32 419.3 32 384C32 348.7 60.7 320 96 320zM320 416C337.7 416 352 401.7 352 384C352 366.3 337.7 352 320 352C302.3 352 288 366.3 288 384C288 401.7 302.3 416 320 416zM320 320C355.3 320 384 348.7 384 384C384 419.3 355.3 448 320 448C284.7 448 256 419.3 256 384C256 348.7 284.7 320 320 320zM576 384C576 366.3 561.7 352 544 352C526.3 352 512 366.3 512 384C512 401.7 526.3 416 544 416C561.7 416 576 401.7 576 384zM480 384C480 348.7 508.7 320 544 320C579.3 320 608 348.7 608 384C608 419.3 579.3 448 544 448C508.7 448 480 419.3 480 384zM32 544L32 560C32 568.8 24.8 576 16 576C7.2 576 0 568.8 0 560L0 544C0 508.7 28.7 480 64 480L128 480C163.3 480 192 508.7 192 544L192 560C192 568.8 184.8 576 176 576C167.2 576 160 568.8 160 560L160 544C160 526.3 145.7 512 128 512L64 512C46.3 512 32 526.3 32 544zM288 512C270.3 512 256 526.3 256 544L256 560C256 568.8 248.8 576 240 576C231.2 576 224 568.8 224 560L224 544C224 508.7 252.7 480 288 480L352 480C387.3 480 416 508.7 416 544L416 560C416 568.8 408.8 576 400 576C391.2 576 384 568.8 384 560L384 544C384 526.3 369.7 512 352 512L288 512zM480 544L480 560C480 568.8 472.8 576 464 576C455.2 576 448 568.8 448 560L448 544C448 508.7 476.7 480 512 480L576 480C611.3 480 640 508.7 640 544L640 560C640 568.8 632.8 576 624 576C615.2 576 608 568.8 608 560L608 544C608 526.3 593.7 512 576 512L512 512C494.3 512 480 526.3 480 544z"/></svg>',blokkeren:'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640"><path d="M93.3 339.9L189.5 508C196.6 520.4 209.9 528.1 224.2 528.1L415.8 528.1C430.1 528.1 443.4 520.4 450.5 508L546.7 339.9C553.7 327.6 553.7 312.5 546.7 300.2L450.5 132.1C443.4 119.7 430.2 112 415.8 112L224.2 112C209.9 112 196.6 119.7 189.5 132.1L93.3 300.2C86.3 312.5 86.3 327.6 93.3 339.9zM65.5 355.8C52.8 333.6 52.8 306.4 65.5 284.3L161.7 116.2C174.5 93.8 198.4 80 224.2 80L415.8 80C441.6 80 465.5 93.8 478.3 116.2L574.5 284.3C587.2 306.5 587.2 333.7 574.5 355.8L478.3 523.9C465.5 546.3 441.6 560.1 415.8 560.1L224.2 560.1C198.4 560.1 174.5 546.3 161.7 523.9L65.5 355.8zM228.7 228.7C234.9 222.5 245.1 222.5 251.3 228.7L320 297.4L388.7 228.7C394.9 222.5 405.1 222.5 411.3 228.7C417.5 234.9 417.5 245.1 411.3 251.3L342.6 320L411.3 388.7C417.5 394.9 417.5 405.1 411.3 411.3C405.1 417.5 394.9 417.5 388.7 411.3L320 342.6L251.3 411.3C245.1 417.5 234.9 417.5 228.7 411.3C222.5 405.1 222.5 394.9 228.7 388.7L297.4 320L228.7 251.3C222.5 245.1 222.5 234.9 228.7 228.7z"/></svg>',aangepast:o}[e]||o}function vn(e){return{learnmate:"LearnMate actief",safemate:"SafeMate actief",classmate:"ClassMate actief",blokkeren:"Blokkeren actief",aangepast:"Aangepast actief"}[e]||"AI Safety actief"}function fi(e){Ie();let t=document.getElementById(A);return t||(t=document.createElement("div"),t.id=A,t.className=`profile-${e}`,t.setAttribute("role","status"),t.setAttribute("aria-live","polite"),t.title=vn(e),t.innerHTML=wn(e),document.documentElement.appendChild(t),t)}function En(e){let t=e.badgeProfile||"learnmate",n=li();ut=n;let o=fi(t),i=`profile-${t}`;o.className!==i&&(o.className=i,o.innerHTML=wn(t),o.title=vn(t)),di(o,n),ui(o,n),xn||(xn=!0,window.addEventListener("beforeunload",()=>{let a=document.getElementById(A);if(a&&ut){q!==null&&(window.clearTimeout(q),q=null);let s=a.getBoundingClientRect(),{w:r,h:c}=ae(),l=B(s.left,0,r-s.width),d=B(s.top,0,c-s.height),u={leftPct:l/r,topPct:d/c};try{let f=$();f&&f.set({[ut]:u})}catch{}}})),yn||(yn=!0,F?.storage?.onChanged?.addListener?.((a,s)=>{if((s==="sync"||s==="local")&&a[n]){let r=document.getElementById(A);if(!r)return;try{let c=a[n].newValue;if(!c||typeof c!="object")return;let{w:l,h:d}=ae(),u=r.getBoundingClientRect(),f=B(Math.round((c.leftPct??0)*l),0,l-u.width),p=B(Math.round((c.topPct??0)*d),0,d-u.height);r.style.left=`${f}px`,r.style.top=`${p}px`,r.style.right="auto",r.style.bottom="auto"}catch{}}}))}function mi(){document.getElementById(A)?.remove(),pi()}function Be(e){Me=e,e.enabled?En(e):mi()}function pt(){if(!Me||!Me.enabled)return!1;let e=document.getElementById(A);return e&&document.documentElement.contains(e)?!1:(En(Me),!0)}function pi(){for(let e of[...L])e.timeout&&window.clearTimeout(e.timeout),e.element.remove();L.length=0,M&&(M.remove(),M=null)}function se(e){if(Ie(),!document.getElementById(A))return;let n=document.createElement("div");n.className=`ai-safety-notification profile-${e.profile}`;let o=document.createElement("button");o.className="ai-safety-notification-close",o.setAttribute("aria-label","Sluiten"),o.textContent="\xD7";let i={element:n,timeout:0,data:e};o.addEventListener("click",()=>{Y(i)}),n.appendChild(o);let a=document.createElement("p");if(a.className="ai-safety-notification-content",a.innerHTML=e.message,n.appendChild(a),e.detail){let s=document.createElement("p");s.className="ai-safety-notification-detail",s.textContent=e.detail,n.appendChild(s)}document.documentElement.appendChild(n),i.timeout=window.setTimeout(()=>{Y(i)},8e3),L.push(i),De()}function Y(e){e.timeout&&window.clearTimeout(e.timeout);let t=L.indexOf(e);t>-1&&L.splice(t,1),e.element.classList.add("hiding"),setTimeout(()=>{e.element.parentNode&&e.element.parentNode.removeChild(e.element),De()},300)}function De(){let e=document.getElementById(A);if(!e)return;let t=e.getBoundingClientRect(),n=window.innerWidth,o=window.innerHeight,i=20,a=16,s=t.top-a,r=o-t.bottom-a,c=s>r;L.forEach(p=>{p.element.style.display="block"});let l=0,d=0,u=c?s:r;for(let p=L.length-1;p>=0;p--){let x=L[p].element.getBoundingClientRect().height,h=d+x+(l>0?ft:i);if(h<=u)l++,d=h;else break}if(c){let p=o-t.top+i;for(let m=L.length-1;m>=L.length-l;m--){let x=L[m].element,h=x.getBoundingClientRect(),w=t.left;w+h.width>n-a&&(w=n-h.width-a),w<a&&(w=a),x.style.left=`${w}px`,x.style.bottom=`${p}px`,x.style.top="auto",x.style.display="block",p+=h.height+ft}}else{let p=t.bottom+i;for(let m=L.length-1;m>=L.length-l;m--){let x=L[m].element,h=x.getBoundingClientRect(),w=t.left;w+h.width>n-a&&(w=n-h.width-a),w<a&&(w=a),x.style.left=`${w}px`,x.style.top=`${p}px`,x.style.bottom="auto",x.style.display="block",p+=h.height+ft}}for(let p=0;p<L.length-l;p++)L[p].element.style.display="none";let f=L.length-l;gi(f,t,n,c,l)}function gi(e,t,n,o,i){if(e>0&&i>0){M||(M=document.createElement("div"),M.className="ai-safety-notification-overflow",document.documentElement.appendChild(M)),M.textContent=`+ ${e} meer`,M.style.display="block";let a=16,s=t.left,r=M.getBoundingClientRect();if(s+r.width>n-a&&(s=n-r.width-a),s<a&&(s=a),M.style.left=`${s}px`,o){let c=L[L.length-i];if(c){let l=c.element.getBoundingClientRect(),d=window.innerHeight-l.top+12;M.style.bottom=`${d}px`,M.style.top="auto"}}else{let c=L[L.length-i];if(c){let d=c.element.getBoundingClientRect().bottom+12;M.style.top=`${d}px`,M.style.bottom="auto"}}}else M&&(M.style.display="none")}function kn(e,t){if(mt)return;try{if(sessionStorage.getItem(ze)==="true")return}catch{}if(mt=!0,Ie(),!document.getElementById(A))return;let o=document.createElement("div");o.className=`ai-safety-notification profile-${e}`;let i=document.createElement("button");i.className="ai-safety-notification-close",i.setAttribute("aria-label","Sluiten"),i.textContent="\xD7";let a={element:o,timeout:0,data:{message:"",profile:e}};i.addEventListener("click",()=>{try{sessionStorage.setItem(ze,"true")}catch{}Y(a)}),o.appendChild(i);let s=document.createElement("p");s.className="ai-safety-notification-content",s.innerHTML="<strong>Dit is een AI site.</strong><br>We raden aan om te veranderen van profiel voor veiliger gebruik.",o.appendChild(s);let r=document.createElement("div");r.className="ai-safety-notification-actions";let c=document.createElement("button");c.className="ai-safety-profile-switch-btn",c.type="button";let l='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640"><path d="M237.3 66.9C247.6 56.1 261.2 48 278 48C290.9 48 302.4 53 310.7 57C314.6 58.8 317.8 59.7 320 59.7C322.2 59.7 325.4 58.9 329.3 57C337.6 53 349.1 48 362 48C378.8 48 392.4 56.2 402.7 66.9C412.9 77.5 420.7 91.5 426.7 105.7C436.5 128.7 442.6 154.9 445.9 176L479.9 176C488.7 176 495.9 183.2 495.9 192C495.9 200.8 488.7 208 479.9 208L447.9 208L447.9 240C447.9 257 444.6 273.2 438.6 288L479.9 288C485.3 288 490.2 290.7 493.2 295.1C496.2 299.5 496.7 305.2 494.7 310.1L460.3 392.8C483.9 407.4 503.3 429.4 517.4 454.2C534.1 483.7 544 518.4 544 551.9L544 559.9C544 568.7 536.8 575.9 528 575.9C519.2 575.9 512 568.7 512 559.9L512 551.9C512 524.4 503.8 495.1 489.6 469.9C475.3 444.7 455.5 424.7 433.3 414.4C425.5 410.8 422 401.7 425.3 393.7L456.1 319.9L420 319.9C396.5 349.2 360.5 367.9 320.1 367.9C279.7 367.9 243.6 349.2 220.2 319.9L184.1 319.9L214.9 393.7C218.2 401.6 214.7 410.7 206.9 414.4C184.6 424.7 164.9 444.7 150.6 469.9C136.3 495 128.2 524.3 128.2 551.9L128.2 559.9C128.2 568.7 121 575.9 112.2 575.9C103.4 575.9 96 568.8 96 560L96 552C96 518.5 105.8 483.8 122.6 454.3C136.7 429.4 156.1 407.4 179.7 392.9L145.2 310.2C143.1 305.3 143.7 299.6 146.7 295.2C149.7 290.8 154.7 288.1 160 288.1L201.3 288.1C195.3 273.3 192 257.1 192 240.1L192 208.1L160 208.1C151.2 208.1 144 200.9 144 192.1C144 183.3 151.2 176.1 160 176.1L194 176.1C197.3 155.1 203.5 128.8 213.2 105.8C219.2 91.5 227.1 77.6 237.2 67zM226.4 176L413.5 176C410.4 157.9 405 136.5 397.3 118.3C392 105.9 386 95.8 379.6 89.1C373.3 82.5 367.6 80 362 80C356.8 80 351 82 343 85.9C337 88.8 328.8 91.7 320 91.7C311.2 91.7 303 88.8 297 85.9C289 82.1 283.2 80 278 80C272.4 80 266.6 82.5 260.4 89.1C254 95.8 248 105.9 242.7 118.3C234.9 136.6 229.6 157.9 226.5 176zM228.2 268.4C240.4 307.6 276.9 336 320 336C363.1 336 399.6 307.6 411.7 268.4C405.6 270.7 398.9 272 392 272L364.8 272C346.8 272 330.3 263.4 320 249.6C309.6 263.5 293.1 272 275.2 272L248 272C241.1 272 234.4 270.7 228.3 268.4zM416 216L416 208L336.9 208L342.1 223.6C345.4 233.4 354.5 240 364.9 240L392.1 240C405.4 240 416.1 229.3 416.1 216zM303.1 208L224 208L224 216C224 229.3 234.7 240 248 240L275.2 240C285.5 240 294.7 233.4 298 223.6L303.2 208zM352 432L342.2 432L383.2 554.9C384.8 559.8 384 565.1 381 569.3C378 573.5 373.2 575.9 368 575.9L272 575.9C266.9 575.9 262 573.4 259 569.3C256 565.2 255.2 559.8 256.8 554.9L297.8 432L288 432C279.2 432 272 424.8 272 416C272 407.2 279.2 400 288 400L352 400C360.8 400 368 407.2 368 416C368 424.8 360.8 432 352 432zM320 466.6L294.2 544L345.8 544L320 466.6z"/></svg>';c.innerHTML=l+" SafeMate",c.addEventListener("click",()=>{try{sessionStorage.setItem(ze,"true")}catch{}Y(a),t()}),r.appendChild(c),o.appendChild(r),document.documentElement.appendChild(o),a.timeout=window.setTimeout(()=>{Y(a)},3e5),L.push(a),De()}function Cn(){mt=!1;try{sessionStorage.removeItem(ze)}catch{}}function gt(e,t,n,o,i="Verbergen",a,s){if(Ie(),!document.getElementById(A))return;let c=document.createElement("div");c.className=`ai-safety-notification profile-${e}`;let l=document.createElement("button");l.className="ai-safety-notification-close",l.setAttribute("aria-label","Sluiten"),l.textContent="\xD7";let d={element:c,timeout:0,data:{message:t,detail:n,profile:e}};l.addEventListener("click",()=>{Y(d),a?.()}),c.appendChild(l);let u=document.createElement("p");if(u.className="ai-safety-notification-content",u.innerHTML=t,c.appendChild(u),n){let m=document.createElement("p");m.className="ai-safety-notification-detail",m.innerHTML=n,c.appendChild(m)}let f=document.createElement("div");f.className="ai-safety-notification-actions";let p=document.createElement("button");p.className="ai-safety-hide-btn",p.type="button",p.innerHTML=i,p.addEventListener("click",()=>{Y(d),o()}),f.appendChild(p),c.appendChild(f),document.documentElement.appendChild(c),d.timeout=window.setTimeout(()=>{Y(d),s?.()},15e3),L.push(d),De()}var A,q,yn,xn,ut,Me,ft,L,M,mt,ze,Re=_(()=>{"use strict";dt();A="ai-safety-badge";q=null;yn=!1,xn=!1,ut=null;Me=null;ft=12,L=[],M=null;mt=!1,ze="ai_safety_ai_website_notification_dismissed"});var Tn=_(()=>{"use strict"});var C,Ln,E,Ne=_(()=>{"use strict";C={email:/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+(?:\.[A-Z]{2,})+(?=[\s,;.!?])/gi,phone:/(?:(?:\+32|0032|0)(?:\s)?(?:[1-9]\d{0,1})(?:[\s\-./])?(?:\d{2,3})(?:[\s\-./])?(?:\d{2})(?:[\s\-./])?(?:\d{2})|(?:\+31|0031|0)(?:\s)?(?:[1-9]\d{1})(?:[\s\-./])?(?:\d{3})(?:[\s\-./])?(?:\d{4})|(?:\+352)(?:\s)?(?:\d{3})(?:[\s\-./])?(?:\d{3})|(?:\+33|0033|0)(?:\s)?(?:[1-9])(?:[\s\-./])?(?:\d{2})(?:[\s\-./])?(?:\d{2})(?:[\s\-./])?(?:\d{2})(?:[\s\-./])?(?:\d{2})|(?:\+49|0049|0)(?:\s)?(?:\d{2,5})(?:[\s\-./])?(?:\d{3,10}))(?=[\s,;.!?])/g,iban:/[A-Z]{2}\d{2}(?:[\s]?[A-Z0-9]{4}){2,7}(?:[\s]?[A-Z0-9]{1,4})?/gi,cc:/\d(?:[\s\-]{0,3}\d){12,18}/g,bsn:/(?<!\d)\d{2}[. ]?\d{2}[. ]?\d{2}[- ]?\d{3}[. ]?\d{2}(?!\d)/g,street:/\b[A-Za-zÀ-ÿ.'\-]{2,}(?:straat|laan|weg|dreef|plein|lei|baan)\b/gi,city:/\b(?:Antwerpen|Brussel|Gent|Charleroi|Luik|Brugge|Namen|Leuven|Bergen|Aalst|Mechelen|Kortrijk|Hasselt|Oostende|Sint-Niklaas|Genk|Roeselare|Moeskroen|Turnhout|Vilvoorde|Lokeren|Sint-Truiden|Beringen|Dendermonde|Heist-op-den-Berg|Nijvel|Brasschaat|Tienen|Lommel|Deinze|Halle|Waregem|Mol|Menen|Knokke-Heist|Ieper|Tongeren|Wavre|Châtelet|Seraing|Verviers|Tournai|Mons|Liège|Namur|Lier|Aarschot|Dilbeek|Grimbergen|Zaventem|Tielt|Izegem|Ronse|Oudenaarde|Geraardsbergen|Ath|Binche|Arlon|Bastogne|Eupen|Blankenberge|De Panne|Geel|Zottegem|Balen|Harelbeke|Poperinge|Bilzen|Tessenderlo|Borgerhout|Deurne|Berchem|Merksem|Wilrijk|Hoboken|Ekeren|Kiel|Mortsel|Edegem|Kontich|Boechout|Schoten|Wijnegem|Wommelgem|Ranst|Hove|Aartselaar|Zwijndrecht|Burcht|Beveren|Sint-Amands)\b/gi,address:/\b[A-Za-zÀ-ÿ.'\-]{2,}(?:straat|laan|weg|dreef|plein|lei|baan)\b|\b(?:Antwerpen|Brussel|Gent|Charleroi|Luik|Brugge|Namen|Leuven|Bergen|Aalst|Mechelen|Kortrijk|Hasselt|Oostende|Sint-Niklaas|Genk|Roeselare|Moeskroen|Turnhout|Vilvoorde|Lokeren|Sint-Truiden|Beringen|Dendermonde|Heist-op-den-Berg|Nijvel|Brasschaat|Tienen|Lommel|Deinze|Halle|Waregem|Mol|Menen|Knokke-Heist|Ieper|Tongeren|Wavre|Châtelet|Seraing|Verviers|Tournai|Mons|Liège|Namur|Lier|Aarschot|Dilbeek|Grimbergen|Zaventem|Tielt|Izegem|Ronse|Oudenaarde|Geraardsbergen|Ath|Binche|Arlon|Bastogne|Eupen|Blankenberge|De Panne|Geel|Zottegem|Balen|Harelbeke|Poperinge|Bilzen|Tessenderlo|Borgerhout|Deurne|Berchem|Merksem|Wilrijk|Hoboken|Ekeren|Kiel|Mortsel|Edegem|Kontich|Boechout|Schoten|Wijnegem|Wommelgem|Ranst|Hove|Aartselaar|Zwijndrecht|Burcht|Beveren|Sint-Amands)\b/gi,dob:/\b(?:(?:geboren|geboortedatum|birth\s*date|DOB)(?:\s+is|\s*[:\s-])\s*(?:\d{1,2}[-/.\s]\d{1,2}[-/.\s]\d{2,4}|\d{1,2}\s+(?:januari|februari|maart|april|mei|juni|juli|augustus|september|oktober|november|december|jan|feb|mrt|apr|jun|jul|aug|sep|okt|nov|dec)\s+\d{4})|\d{1,2}\/\d{1,2}\/\d{4})\b/gi,age:/(?:(?:leeftijd|age)[:\s-]*\d{1,3}|\d{1,3}\s*(?:jaar|jarige|j\b))/gi,children:/(?:mijn\s*zoon|mijn\s*dochter|kind(?:\s*van\s*\d)?|dochter|zoon|kleuter|basisschool)/gi,health:/(medicatie|diagnose|depressie|autisme|adhd|migraine|bipolair|ziekte|gezondheid|diabetes|epilepsie|astma|eczeem|voedselallergieën|ibs|darmstoornis|rugproblemen|rugprobleem|scoliose|scoliosis|koorts|chronische\s*pijn|immunotherapie|hormonale\s*behandelingen|inhalator|puffer|ventolin|antibiotica|antihistamine|cortisone|aspirine|paracetamol|ibuprofen|dafalgan|insuline|bloedverdunners|statines|antidepressiva|pijnstillers|slaappillen|antacida|laxeermiddel|omeprazol|metformine|levothyroxine|simvastatine|atorvastatine|amoxicilline|prednison|salbutamol|ritalin|concerta|lexapro|sertraline|prozac|xanax|lorazepam|zolpidem|codeine|morfine|fentanyl|oxycodon)/gi,crisis:/\b(?:selfharm|self-harm|automutilatie|zelfbeschadiging|suicide|suïcide|suïcida(?:al|le|liteit)|zelfmoord(?:gedachten|plan|poging)?|denken aan zelfmoord|denk aan zelfmoord|ik wil (?:dood|er niet meer zijn|niet meer leven|sterven)|ik kan niet meer|ik zie geen uitweg|geen reden om te leven|einde maken aan|er een eind aan|ik wil eruit stappen|stap eruit|levensmoe|wanhopig|mishandeling|huiselijk geweld|geweld plegen|terror|terreur|aanslag|bom(?:melding)?)\b/gi,jailbreak:/\b(bypass safety|jailbreak|pretend to be|act as if|ignore (previous|all) (instructions|rules|guidelines)|you are now|from now on you are|roleplay as|simulate|disregard (your|the) (programming|guidelines|rules)|forget (your|all) (instructions|rules|constraints))\b/gi,courtcase:/\bA\.R\.\s*\d{4}\/\d+\b|\b[A-Z]{2}\.\d{2}\.[A-Z0-9]\d?\.\d{4,6}\/\d{4}\b/gi,insz:/\b(?:9[0-9]|[0-8][0-9])\.\d{2}\.\d{2}-\d{3}\.\d{2}\b/g,vat:/\b(?:BE\s*0?\d{9}|DE\s*\d{9}|FR\s*[A-Z0-9]{2}\s*\d{9}|NL\s*\d{9}B\d{2}|GB\s*\d{9}(?:\d{3})?)\b/gi,kbo:/\b0\d{3}\.?\d{3}\.?\d{3}\b/g,salary:/(?:€|EUR|USD|\$|£)\s*\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?|\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?\s*(?:EUR|USD|GBP)/gi},Ln=new Set(["opslaan","inslaan","doorslaan","aanslaan","uitslaan","afslaan","terugslaan","neerslaan","toeslaan","omslaan","overslaan","dichtslaan","openslaan","stukslaan","kapotslaan","platslaan","misslaan","vastslaan","losslaan","raakslaan","gadeslaan","opsla","insla","doorsla","aansla","uitsla","afsla","onderweg","tussenweg","uitweg","omweg","allerlei","velerlei","twee\xEBrlei","drie\xEBrlei","autobaan","rijbaan"]),E={email:"<EMAIL>",phone:"<PHONE>",iban:"<IBAN>",cc:"<CARD>",bsn:"<NATID>",street:"<STREET>",city:"<CITY>",address:"<ADDRESS>",dob:"<DOB>",age:"<AGE>",children:"<CHILDREN>",name:"<NAME>",health:"<HEALTH>",crisis:"<GEVOELIG>",courtcase:"<DOSSIER>",insz:"<INSZ>",vat:"<BTW>",kbo:"<KBO>",salary:"<SALARIS>"}});function ht(e){return hi.has(e.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,""))}var hi,bt=_(()=>{"use strict";hi=new Set(["adam","alexander","alexis","arne","arthur","axel","bart","bas","ben","boris","bram","brent","cedric","charles","chris","christophe","daan","david","dennis","dieter","dimitri","dries","elias","emile","ethan","evert","filip","florian","frank","frederik","gert","glenn","guillaume","hans","hendrik","hugo","ivan","jan","jarne","jarno","jasper","jef","jelle","jenthe","jeroen","jesse","joachim","joeri","jonas","jonathan","joren","joris","jules","julien","karel","kevin","kobe","koen","kristof","lars","lasse","laurens","lenn","lennart","lente","leon","liam","lore","louis","lowie","luca","lucas","lukas","marc","marco","marnix","marten","mathias","mathieu","matteo","matthias","max","maxim","michael","michiel","milan","nand","nathan","nick","nicolas","niels","noah","noel","olivier","oscar","patrick","paul","peter","philippe","pieter","quinten","raf","raphael","reinout","rik","robbe","robin","ruben","ryan","sam","sander","sebastiaan","siebe","siem","simon","stan","stef","stefan","stijn","sven","thijs","thomas","tibo","tijs","tim","tobias","tom","toon","vic","victor","vincent","wannes","ward","warre","wim","wout","wouter","xander","yannick","yarne","yente","zeno","amber","amelie","amy","an","anna","anouk","astrid","axelle","bo","britt","celine","charlotte","chloe","clara","colette","dagmar","dana","elena","elien","eline","elisa","elise","ella","emma","evi","evie","fien","fleur","floor","greet","griet","hailey","hanne","helena","ines","jana","janne","jasmine","jill","jolien","julie","justine","karen","kaat","katrien","kim","laure","laura","lena","lies","lien","liesbet","lina","lisa","loes","lotte","louise","luna","manon","margot","marie","marthe","maud","maya","merel","mieke","mila","nathalie","nele","nina","noor","nora","olivia","pauline","roos","ruth","sarah","silke","sofie","sophie","stien","tessa","tine","valerie","vera","veerle","yasmine","zoe","mohammed","mohamed","mehdi","youssef","youssouf","ahmed","hamza","amine","ayoub","bilal","ilias","imran","ismael","ismail","karim","khalid","malik","marwan","nabil","omar","othman","rachid","rayan","said","samir","soufiane","tarik","walid","yassine","zakaria","zaki","abdel","abdelkader","abderrahim","brahim","driss","hassan","hicham","jamal","mouad","moussa","mustapha","noureddine","redouan","younes","amira","fatima","hafsa","hanane","ikram","imane","khadija","layla","leila","malika","mariam","meryem","nadia","naima","nora","noura","oumaima","rajae","rania","salma","samira","sara","siham","soukaina","wafa","yasmin","zahra","zineb","ahmet","ali","burak","can","cemal","emre","enes","erkan","fatih","ferhat","furkan","gokhan","hakan","huseyin","ibrahim","kemal","kerem","mehmet","murat","mustafa","oguzhan","onur","osman","recep","selim","serkan","sinan","suleyman","tolga","ufuk","umut","volkan","yilmaz","yunus","yusuf","ayse","busra","ceren","deniz","derya","elif","emine","esra","fatma","gamze","gul","gulsen","hatice","irem","kubra","melek","merve","mine","nese","nur","ozge","ozlem","selin","sevgi","tugba","yasemin","zehra","zeynep","andrzej","bartosz","damian","dawid","dominik","grzegorz","jakub","kamil","krzysztof","lukasz","maciej","marcin","mateusz","michal","pawel","piotr","rafal","sebastian","szymon","tomasz","wojciech","agnieszka","aleksandra","anna","beata","dorota","ewa","iwona","joanna","justyna","karolina","katarzyna","magdalena","malgorzata","monika","natalia","patrycja","paulina","sylwia","weronika","alexandru","andrei","bogdan","catalin","ciprian","cosmin","cristian","daniel","dragos","florin","george","ionut","marian","mihai","razvan","stefan","vlad","alina","andreea","cristina","diana","elena","gabriela","ioana","maria","mihaela","raluca","roxana","simona","aimee","chance","christian","claude","dieudonne","emmanuel","eric","fabrice","franck","grace","herve","innocent","jean-pierre","junior","patrick","prince","rachel","ruth","samuel","serge","tresor","aline","ange","belle","chantal","deborah","esther","gloria","joelle","marie-claire","naomie","noella","olive","pascale","amir","arjun","deepak","dinesh","gaurav","hari","kumar","mahesh","naveen","pradeep","raj","rajesh","ravi","rohit","sachin","sandeep","sanjay","suresh","vijay","vikram","anita","deepa","divya","geeta","kavita","lakshmi","meena","nisha","pooja","priya","radha","rani","rekha","ritu","seema","shanti","sita","sunita","usha","chen","cheng","feng","hong","hua","hui","jing","lei","li","lian","lin","ling","mei","ming","ping","wei","xin","yan","ying","yu","yun","zhen","anh","binh","dung","hai","hang","hanh","hien","hoa","huong","khanh","lan","linh","loc","long","minh","nam","nga","ngan","ngoc","nhat","phuong","quang","tam","thanh","thao","thi","thien","thuy","tien","trang","trung","tuan","van","vu","abena","adjoa","akua","ama","chidera","chidi","chioma","emeka","kofi","kwame","kwesi","nana","obinna","olu","tunde","yaw","alejandro","carlos","diego","fernando","francisco","gabriela","isabella","jorge","jose","juan","lucia","luis","manuel","maria","miguel","pablo","pedro","ricardo","rosa","valentina"])});function yi(e,t){let n=[];for(let{rx:o,type:i,replacement:a,settingsKey:s}of bi){if(!t[s])continue;o.lastIndex=0;let r;for(;(r=o.exec(e))!==null;)n.push({type:i,start:r.index,end:r.index+r[0].length,text:r[0],replacement:a})}return n}function wi(e,t){let n=[];for(let{rx:o,type:i,replacement:a,settingsKey:s,group:r}of xi){if(!t[s])continue;o.lastIndex=0;let c;for(;(c=o.exec(e))!==null;){let l=c[r];!l||l.trim().length<2||n.push({type:i,start:c.index,end:c.index+c[0].length,text:c[0],replacement:a})}}return n}function Ci(e,t){if(!t.mask_name)return[];let n=[],o=[Ei,vi,ki];for(let i of o){i.lastIndex=0;let a;for(;(a=i.exec(e))!==null;){let s=a[1];!s||s.length<2||new Set(["van","de","het","een","die","dat","dan","wel","nie","nog"]).has(s.toLowerCase())||!ht(s)||n.some(l=>a.index>=l.start&&a.index<l.end)||n.push({type:"name",start:a.index,end:a.index+a[0].length,text:a[0],replacement:"<NAME>"})}}return n}function Li(e,t){if(!t.mask_name)return[];let n=[];for(let o of Ti){o.lastIndex=0;let i;for(;(i=o.exec(e))!==null;){let a=i[1];if(!a||a.length<2)continue;let s=i.index+i[0].indexOf(a),r=s+a.length;n.push({type:"name",start:s,end:r,text:a,replacement:"<NAME>"})}}return n}function Ai(e,t){if(!t.mask_name)return[];let n=[];Sn.lastIndex=0;let o;for(;(o=Sn.exec(e))!==null;){let i=o[1];if(i.length<2||!ht(i))continue;let a=Si.get(i.toLowerCase());if(a){let s=e.slice(o.index+i.length);if(a.test(s))continue}n.push({type:"name",start:o.index,end:o.index+i.length,text:i,replacement:"<NAME>"})}return n}function Pe(e,t){if(!e||e.length===0)return[];let n=[...yi(e,t),...wi(e,t),...Ci(e,t),...Li(e,t),...Ai(e,t)];n.sort((i,a)=>i.start-a.start);let o=[];for(let i of n)o.some(s=>i.start<s.end&&i.end>s.start)||o.push(i);return o}var bi,xi,vi,Ei,ki,Ti,Sn,Si,yt=_(()=>{"use strict";Ne();bt();bi=[{rx:/\b(?:tel\.?\s*nr\.?|gsm[\s-]?nr\.?)\b/gi,type:"phone",replacement:E.phone,settingsKey:"mask_phone"},{rx:/\b(?:e[\s-]?mail\s*adres|mailadres)\b/gi,type:"email",replacement:E.email,settingsKey:"mask_email"},{rx:/\bgeb\.?\s*datum\b/gi,type:"dob_age",replacement:E.dob,settingsKey:"mask_dob_age"}];xi=[{rx:/(?:ik\s+)?woon\s+in(?:\s+de)?\s+(\S.{1,29}?)(?=[\s,;.!?])/gi,type:"address",replacement:E.address,settingsKey:"mask_address",group:1},{rx:/mijn\s+adres(?:s)?\s+is\s+(\S.{1,39}?)(?=[\s,;.!?])/gi,type:"address",replacement:E.address,settingsKey:"mask_address",group:1},{rx:/ik\s+ben\s+(\d{1,3})\s*(?:jaar|j\.?)(?=[\s,;.!?])/gi,type:"dob_age",replacement:E.age,settingsKey:"mask_dob_age",group:1},{rx:/geboren\s+(?:op\s+)?(\d{1,2}\s+\w+\s+\d{4}|\d{1,2}[-/.]\d{1,2}[-/.]\d{2,4})(?=[\s,;.!?])/gi,type:"dob_age",replacement:E.dob,settingsKey:"mask_dob_age",group:1}];vi=/\b(?:m(?:'?n|ijn))\s+(?:mama|papa|moeder|vader|broer|zus|zusje|broertje|vriend|vriendin|neef|nicht|oom|tante|opa|oma)\s+(?:heet\s+)?(\w+)(?=[\s,;.!?])/gi,Ei=/\b(?:m(?:'?n|ijn))\s+(?:mama|papa|moeder|vader|broer|zus|zusje|broertje|vriend|vriendin|neef|nicht|oom|tante|opa|oma)\s+heet\s+(\w+)(?=[\s,;.!?])/gi,ki=/\b(?:(?:m(?:'?n|ijn))\s+naam\s+is|ik\s+heet|k\s*ben)\s+(\w+)(?=[\s,;.!?])/gi;Ti=[/\bbetrokkene\s+([A-ZÀ-Ÿ][a-zà-ÿ]+(?:\s+[A-ZÀ-Ÿ][a-zà-ÿ]+)?)\b/g,/\bpatiënt\s+([A-ZÀ-Ÿ][a-zà-ÿ]+(?:\s+[A-ZÀ-Ÿ][a-zà-ÿ]+)?)\b/g,/\bcontactpersoon\s+([A-ZÀ-Ÿ][a-zà-ÿ]+(?:\s+[A-ZÀ-Ÿ][a-zà-ÿ]+)?)\b/g,/\bbericht\s+van\s+([A-ZÀ-Ÿ][a-zà-ÿ]+(?:\s+[A-ZÀ-Ÿ][a-zà-ÿ]+)?)\b/gi,/\bbetrokken\s+partij\s+([A-ZÀ-Ÿ][a-zà-ÿ]+(?:\s+[A-ZÀ-Ÿ][a-zà-ÿ]+)?)\b/gi,/\bnaam\s*:\s*([A-ZÀ-Ÿ][a-zà-ÿ]+(?:\s+[A-ZÀ-Ÿ][a-zà-ÿ]+)?)\b/gi,/\b(?:voor|van)\s+([A-ZÀ-Ÿ][a-zà-ÿ]+\s+[A-ZÀ-Ÿ][a-zà-ÿ]+)\b/g,/\b(?:ondertekend|behandeld|opgesteld|opgemaakt)\s+door\s+([A-ZÀ-Ÿ][a-zà-ÿ]+(?:\s+[A-ZÀ-Ÿ][a-zà-ÿ]+)?)\b/gi];Sn=/\b([A-ZÀ-Ÿ][a-zà-ÿ]{1,})(?=[\s,;.!?:'\)\]"])/g,Si=new Map([["lieve",/^\s+(?:groeten|dame|heer|mevrouw|meneer|collega'?s?|vrienden|allemaal)\b/i]])});function xt(e){return[{enabled:!!e.mask_courtcase,rx:C.courtcase,to:E.courtcase,analyticsType:"courtcase"},{enabled:!!e.mask_insz,rx:C.insz,to:E.insz,analyticsType:"insz"},{enabled:!!e.mask_vat,rx:C.vat,to:E.vat,analyticsType:"vat"},{enabled:!!e.mask_kbo,rx:C.kbo,to:E.kbo,analyticsType:"kbo"},{enabled:!!e.mask_salary,rx:C.salary,to:E.salary,analyticsType:"salary"},{enabled:e.mask_email,rx:C.email,to:E.email,analyticsType:"email"},{enabled:e.mask_iban,rx:C.iban,to:E.iban,analyticsType:"iban"},{enabled:e.mask_cc,rx:C.cc,to:E.cc,analyticsType:"creditcard"},{enabled:e.mask_natid,rx:C.bsn,to:E.bsn,analyticsType:"nationalid"},{enabled:e.mask_phone,rx:C.phone,to:E.phone,analyticsType:"phone"},{enabled:e.mask_address,rx:C.street,to:E.street,analyticsType:"address",falsePositives:Ln},{enabled:e.mask_address,rx:C.city,to:E.city,analyticsType:"address"},{enabled:e.mask_dob_age,rx:C.dob,to:E.dob,analyticsType:"dob_age"},{enabled:e.mask_dob_age,rx:C.age,to:E.age,analyticsType:"dob_age"},{enabled:e.mask_children,rx:C.children,to:E.children,analyticsType:"children"},{enabled:e.mask_health,rx:C.health,to:E.health,analyticsType:"health"},{enabled:e.mask_crisis,rx:C.crisis,to:E.crisis,analyticsType:"crisis"}].filter(t=>t.enabled)}function _i(e,t){let n=[];for(let{rx:o,to:i,analyticsType:a,falsePositives:s}of t){o.lastIndex=0;let r,c=0;for(;(r=o.exec(e))!==null&&!(++c>5e3);)s&&s.has(r[0].toLowerCase())||(a&&n.push({type:a,start:r.index,end:r.index+r[0].length,text:r[0],replacement:i}),r[0].length===0&&o.lastIndex++)}return n}function Mi(e,t){let n=[...e],o=new Set(e.map(a=>a.type));for(let a of t){let s=!1;for(let r=n.length-1;r>=0;r--)n[r].type===a.type&&a.start<=n[r].start&&a.end>=n[r].end&&(n.splice(r,1),s=!0);!s&&o.has(a.type)&&a.text.length<15||n.push(a)}n.sort((a,s)=>a.start-s.start);let i=[];for(let a of n)i.some(r=>a.start<r.end&&a.end>r.start)||i.push(a);return i}function An(e,t){let n=xt(t),o=e,i=new Map;for(let{rx:s,to:r,analyticsType:c,falsePositives:l}of n){s.lastIndex=0;let d=0,u=0;o=o.replace(s,f=>++d>5e3||l&&l.has(f.toLowerCase())?f:(u++,r)),u>0&&c&&i.set(c,(i.get(c)||0)+u)}let a=Pe(o,t);if(a.length>0){let s=[...a].sort((r,c)=>c.start-r.start);for(let r of s){let c=o.slice(0,r.start),l=o.slice(r.end);o=c+r.replacement+l,i.set(r.type,(i.get(r.type)||0)+1)}}return{text:o,sanitizationCounts:i}}function _n(e,t,n){let o=xt(n),i=e,a=[],s=new Map;for(let{rx:d,to:u,analyticsType:f,falsePositives:p}of o){d.lastIndex=0;let m=0,y=0;i=i.replace(d,(x,...h)=>{if(++m>5e3||p&&p.has(x.toLowerCase()))return x;let w=h.at(-2);return a.push({start:w,oldLen:x.length,newLen:u.length}),y++,u}),y>0&&f&&s.set(f,(s.get(f)||0)+y)}let r=Pe(e,n);if(r.length>0){let d=[...r].sort((u,f)=>f.start-u.start);for(let u of d)i.slice(u.start,u.end)===u.text&&(i=i.slice(0,u.start)+u.replacement+i.slice(u.end),a.push({start:u.start,oldLen:u.text.length,newLen:u.replacement.length}),s.set(u.type,(s.get(u.type)||0)+1))}if(i===e)return{text:e,newCaret:t,sanitizationCounts:s};a.sort((d,u)=>d.start-u.start);let c=0;for(let d of a)d.start+d.oldLen<=t?c+=d.newLen-d.oldLen:d.start<t&&t<=d.start+d.oldLen&&(c+=d.newLen-(t-d.start));let l=Math.max(0,Math.min(i.length,t+c));return{text:i,newCaret:l,sanitizationCounts:s}}function re(e,t){let n=xt(t),o=_i(e,n),i=Pe(e,t),a=Mi(o,i),s=new Set;for(let r of a)s.add(r.type);return{matches:a,types:s}}var Mn=_(()=>{"use strict";Ne();yt()});function wt(e){let t=e.toLowerCase().replace(/^www\./i,"");return zn.some(n=>{let o=n.toLowerCase().replace(/^www\./i,"");if(t===o||t.endsWith("."+o))return!0;if(o.includes("/")){let[i]=o.split("/");if(t===i||t.endsWith("."+i))return!0}return!1})}function vt(e,t){let n=e.toLowerCase().replace(/^www\./i,""),o=t.toLowerCase();return zn.some(i=>{if(!i.includes("/"))return!1;let[a,...s]=i.toLowerCase().split("/"),r="/"+s.join("/");return n===a||n.endsWith("."+a)?o.startsWith(r):!1})}var zn,In=_(()=>{"use strict";zn=["chatgpt.com","chat.openai.com","openai.com","gemini.google.com","bard.google.com","aistudio.google.com","labs.google","notebooklm.google.com","claude.ai","anthropic.com","copilot.microsoft.com","copilot.cloud.microsoft","bing.com/chat","bing.com/create","meta.ai","perplexity.ai","chat.mistral.ai","mistral.ai","grok.x.ai","x.ai","chat.deepseek.com","deepseek.com","kimi.ai","kimi.moonshot.cn","doubao.com","yiyan.baidu.com","ernie.baidu.com","tongyi.aliyun.com","xinghuo.xfyun.cn","chatglm.cn","tiangong.cn","phind.com","you.com","exa.ai","consensus.app","elicit.com","poe.com","character.ai","pi.ai","inflection.ai","replika.com","chai-research.com","talkie-ai.com","novelai.net","jasper.ai","writesonic.com","copy.ai","rytr.me","grammarly.com","quillbot.com","wordtune.com","anyword.com","hyperwriteai.com","sudowrite.com","jenni.ai","textcortex.com","simplified.com","notion.so/product/ai","github.com/copilot","replit.com","codeium.com","tabnine.com","bolt.new","v0.dev","cursor.com","codium.ai","midjourney.com","leonardo.ai","ideogram.ai","playground.com","stability.ai","dreamstudio.ai","nightcafe.studio","craiyon.com","runwayml.com","pika.art","suno.com","udio.com","descript.com","elevenlabs.io","synthesia.io","heygen.com","gamma.app","tome.app","beautiful.ai","fireflies.ai","otter.ai","huggingface.co/chat","cohere.com","together.ai","groq.com","forefront.ai","khanmigo.ai","socratic.org","photomath.com"]});var Bn=_(()=>{"use strict"});var ye=_(()=>{"use strict";Tn();Ne();Mn();yt();bt();In();Bn()});var v,As,Dn=_(()=>{"use strict";v=(()=>{let e=globalThis,t=e.browser??e.chrome;if(!t)throw typeof process<"u",new Error("Browser API not found");return t})(),As=(()=>{try{return v?.runtime?.getManifest?.().manifest_version===3}catch{return!1}})()});var zi,Et,kt=_(()=>{"use strict";zi=parseInt("60000",10),Et="https://jhpvlmfcyuatpgoxmknz.supabase.co/functions/v1/analytics"});function Rn(){return"xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,e=>{let t=Math.random()*16|0;return(e==="x"?t:t&3|8).toString(16)})}async function Nn(){if(!v)return{enabled:!1,extensionId:Rn(),installTimestamp:Date.now(),lastSyncTimestamp:0};let e=v.storage.local,t=await e.get(Z);if(t[Z])return t[Z];let s={enabled:(await(v.storage.sync??v.storage.local).get("sanitize_settings")).sanitize_settings?.analytics_enabled??!0,extensionId:Rn(),installTimestamp:Date.now(),lastSyncTimestamp:0};return await e.set({[Z]:s}),s}async function ce(){if(!v)return Nn();let e=v.storage.local,t=await e.get(Z);if(!t[Z])return Nn();let n=t[Z],s=(await(v.storage.sync??v.storage.local).get("sanitize_settings")).sanitize_settings?.analytics_enabled??!0;return n.enabled!==s&&(n.enabled=s,await e.set({[Z]:n})),n}function Fe(e,t){return{sanitizations:{email:0,phone:0,iban:0,creditcard:0,nationalid:0,address:0,dob_age:0,children:0,name:0,health:0,crisis:0,courtcase:0,insz:0,vat:0,kbo:0,salary:0},fileBlocks:{image:0,pdf:0,office:0},crisisDetections:0,jailbreakDetections:0,profile:e,extensionId:t,lastSyncTimestamp:Date.now(),installTimestamp:Date.now()}}async function je(){if(!v)return null;let t=await v.storage.local.get(He);return t[He]?t[He]:null}async function Oe(e){if(!v)return;await v.storage.local.set({[He]:e})}async function V(e,t=1,n){if(!v)return;let o=await ce();if(!o.enabled)return;let r=(await(v.storage.sync??v.storage.local).get("sanitize_settings")).sanitize_settings?.profile||"aangepast",c=await je();c||(c=Fe(r,o.extensionId)),c.sanitizations[e]+=t,c.profile=r,await Oe(c);try{(v?.runtime??(typeof chrome<"u"?chrome.runtime:null))?.sendMessage?.({type:"TRACK_ANALYTICS_EVENT",event:{type:"sanitization",subtype:e,count:t,hostname:n}},()=>{let d=(typeof chrome<"u"?chrome:null)?.runtime?.lastError})}catch{}}async function Pn(e,t=1,n){if(!v)return;let o=await ce();if(!o.enabled)return;let r=(await(v.storage.sync??v.storage.local).get("sanitize_settings")).sanitize_settings?.profile||"aangepast",c=await je();c||(c=Fe(r,o.extensionId)),c.fileBlocks[e]+=t,c.profile=r,await Oe(c);try{(v?.runtime??(typeof chrome<"u"?chrome.runtime:null))?.sendMessage?.({type:"TRACK_ANALYTICS_EVENT",event:{type:"fileBlock",subtype:e,count:t,hostname:n}},()=>{let d=(typeof chrome<"u"?chrome:null)?.runtime?.lastError})}catch{}}async function Hn(e){if(!v)return;let t=await ce();if(!t.enabled)return;let a=(await(v.storage.sync??v.storage.local).get("sanitize_settings")).sanitize_settings?.profile||"aangepast",s=await je();s||(s=Fe(a,t.extensionId)),s.crisisDetections+=1,s.profile=a,await Oe(s);try{(v?.runtime??(typeof chrome<"u"?chrome.runtime:null))?.sendMessage?.({type:"TRACK_ANALYTICS_EVENT",event:{type:"crisisDetection",hostname:e}},()=>{let c=(typeof chrome<"u"?chrome:null)?.runtime?.lastError})}catch{}}async function Fn(e){if(!v)return;let t=await ce();if(!t.enabled)return;let a=(await(v.storage.sync??v.storage.local).get("sanitize_settings")).sanitize_settings?.profile||"aangepast",s=await je();s||(s=Fe(a,t.extensionId)),s.jailbreakDetections+=1,s.profile=a,await Oe(s);try{(v?.runtime??(typeof chrome<"u"?chrome.runtime:null))?.sendMessage?.({type:"TRACK_ANALYTICS_EVENT",event:{type:"jailbreakDetection",hostname:e}},()=>{let c=(typeof chrome<"u"?chrome:null)?.runtime?.lastError})}catch{}}async function Ct(e){if(!v||!(await ce()).enabled)return;let n={event_type:"nudge_displayed",nudge_id:e.nudgeId,pii_types_detected:e.piiTypesDetected,pii_count:e.piiCount,prompt_length_chars:e.promptLengthChars};try{(v?.runtime??(typeof chrome<"u"?chrome.runtime:null))?.sendMessage?.({type:"TRACK_ANALYTICS_EVENT",event:{type:"nudgeDisplayed",hostname:e.hostname,nudgeData:n}},()=>{let i=(typeof chrome<"u"?chrome:null)?.runtime?.lastError})}catch{}}async function jn(e){if(!v||!(await ce()).enabled)return;let n={event_type:"nudge_response",nudge_id:e.nudgeId,response_type:e.responseType,response_time_ms:e.responseTimeMs,pii_removed_count:e.piiRemovedCount,pii_remaining_count:e.piiRemainingCount};try{(v?.runtime??(typeof chrome<"u"?chrome.runtime:null))?.sendMessage?.({type:"TRACK_ANALYTICS_EVENT",event:{type:"nudgeResponse",hostname:e.hostname,nudgeData:n}},()=>{let i=(typeof chrome<"u"?chrome:null)?.runtime?.lastError})}catch{}}var He,Z,G=_(()=>{"use strict";Dn();kt();He="ai_safety_analytics",Z="ai_safety_analytics_settings"});var le,Ke,_t=_(()=>{"use strict";le={email:"e-mailadres",phone:"telefoonnummer",iban:"IBAN-nummer",creditcard:"creditcardnummer",nationalid:"rijksregisternummer",address:"adres",dob_age:"geboortedatum/leeftijd",children:"informatie over kinderen",name:"persoonsnaam",health:"gezondheidsgegevens",crisis:"gevoelige woorden",courtcase:"dossiernummer",insz:"INSZ-nummer",vat:"BTW-nummer",kbo:"KBO-nummer",salary:"salarsinformatie"},Ke={email:"Wist je dat AI-systemen deze gegevens vaak opslaan in hun trainingsdata?",phone:"Telefoonnummers kunnen gebruikt worden om je te identificeren in AI-modellen.",iban:"Financi\xEBle gegevens zijn gevoelig en kunnen misbruikt worden door AI-systemen.",creditcard:"Creditcardgegevens zijn zeer gevoelig en vereisen extra bescherming.",nationalid:"Je BSN is een unieke identificatie en moet priv\xE9 blijven.",address:"Adresgegevens kunnen je locatie onthullen aan AI-systemen.",dob_age:"Leeftijdsinformatie kan gebruikt worden om je te profileren.",children:"Gegevens over kinderen vereisen extra bescherming.",name:"Namen kunnen je identiteit onthullen aan AI-systemen.",health:"Medische informatie is zeer gevoelig en priv\xE9.",crisis:"Voor zulke onderwerpen is het beter om met iemand te praten die je vertrouwt.",courtcase:"Rechtbankdossiers bevatten vertrouwelijke juridische informatie.",insz:"Het rijksregisternummer is een unieke identificatie en moet priv\xE9 blijven.",vat:"BTW-nummers kunnen gebruikt worden om organisaties te identificeren.",kbo:"Het ondernemingsnummer bevat bedrijfsgerelateerde informatie.",salary:"Financi\xEBle vergoedingsgegevens zijn vertrouwelijk."}});function Mt(e,t){let n=le[e]||"gevoelige gegevens",o=Ke[e]||"";return{message:`Ik heb je <strong>${n} verborgen</strong>.`,detail:o||void 0}}function zt(e){return`<strong>${le[e]||"gevoelige gegevens"}</strong>`}function R(e,t){return(n,o)=>{let{text:i,newCaret:a,sanitizationCounts:s}=_n(n,o,e);if(s.size>0){let r=typeof window<"u"?window.location.hostname:void 0;for(let[c,l]of s.entries())V(c,l,r).catch(()=>{});if(t){let c=Array.from(s.keys());if(c.length===1){let{message:l,detail:d}=Mt(c[0],t);se({message:l,detail:d,profile:t})}else{let d=`Ik heb volgende info verborgen:<br>${c.map(u=>`\u2022 ${zt(u)}`).join("<br>")}<br><br>Deze informatie slaat AI op voor trainingsdoeleinden.`;se({message:d,profile:t})}}}return{text:i,newCaret:a}}}function $e(e){try{let t=new InputEvent("input",{bubbles:!0,cancelable:!0,composed:!0});e.dispatchEvent(t)}catch{let t=document.createEvent("Event");t.initEvent("input",!0,!0),e.dispatchEvent(t)}}var Ye=_(()=>{"use strict";ye();G();Re();_t()});function Oi(e){let t=window.getSelection();if(!t||t.rangeCount===0)return null;let n=t.getRangeAt(0);return!e.contains(n.startContainer)||!e.contains(n.endContainer)?null:n.cloneRange()}function Kn(e){let t=[],n=0,o=document.createTreeWalker(e,NodeFilter.SHOW_TEXT,{acceptNode:a=>a.textContent?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_REJECT}),i;for(;i=o.nextNode();){let a=n,s=a+(i.textContent?.length??0);t.push({node:i,start:a,end:s}),n=s}return{text:t.map(a=>a.node.textContent||"").join(""),mapToNode:t}}function Ui(e,t){for(let n of e)if(t>=n.start&&t<=n.end)return{node:n.node,offset:t-n.start};if(e.length){let n=e[e.length-1];return{node:n.node,offset:n.node.textContent?.length??0}}return null}function Wi(e,t){let n=window.getSelection();if(!n)return;let o=document.createRange();o.setStart(e,t),o.setEnd(e,t),n.removeAllRanges(),n.addRange(o)}function $n(e){let t=window.getSelection?.();if(!t||t.rangeCount===0)return;let n=t.getRangeAt(0);n.deleteContents();let o=document.createTextNode(e);n.insertNode(o),n.setStartAfter(o),n.setEndAfter(o),t.removeAllRanges(),t.addRange(n)}function Yn(e,t){let n=Oi(e),{text:o,mapToNode:i}=Kn(e),a=o.length;if(n){a=0;for(let u of i)if(u.node===n.startContainer){a+=n.startOffset;break}else a+=u.node.textContent?.length??0}let{text:s,newCaret:r}=t(o,a);if(s===o)return;let c=s;for(let u=0;u<i.length;u++){let f=i[u],p=f.node.textContent?.length??0;if(u<i.length-1){let m=c.slice(0,p);f.node.textContent=m,c=c.slice(p)}else f.node.textContent=c,c=""}c.length>0&&e.appendChild(document.createTextNode(c));let l=Kn(e).mapToNode,d=Ui(l,r);d&&Wi(d.node,d.offset),$e(e)}var Zn=_(()=>{"use strict";Ye()});var zo,it,ot,Co,To,Kt,$t,ga,fe,ha,z,ba,ya,xa,P,rt,Vt,Io,Bo,W,Lo,Do,Ro,wa,Ce,va,at,Q,T,So,g,No,Ea,Po,Ho,Yt,Zt,te,ne,ee,Fo,jo,N,ka,Ao,Ca,Gt,Xt,Ta,Oo,Jt,La,Qt,Sa,Aa,Uo,_a,Ma,Wo,st,za,Ko,qt,Ia,_o,Mo,Ba,$o=_(()=>{zo=Object.freeze({p:0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffedn,n:0x1000000000000000000000000000000014def9dea2f79cd65812631a5cf5d3edn,h:8n,a:0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffecn,d:0x52036cee2b6ffe738cc740797779e89800700a4d4141d8ab75eb4dca135978a3n,Gx:0x216936d3cd6e53fec0a4e231fdd6dc5c692cc7609525a7b2c9562d608f25d51an,Gy:0x6666666666666666666666666666666666666666666666666666666666666658n}),{p:it,n:ot,Gx:Co,Gy:To,a:Kt,d:$t,h:ga}=zo,fe=32,ha=(...e)=>{"captureStackTrace"in Error&&typeof Error.captureStackTrace=="function"&&Error.captureStackTrace(...e)},z=(e="")=>{let t=new Error(e);throw ha(t,z),t},ba=e=>typeof e=="bigint",ya=e=>typeof e=="string",xa=e=>e instanceof Uint8Array||ArrayBuffer.isView(e)&&e.constructor.name==="Uint8Array"&&"BYTES_PER_ELEMENT"in e&&e.BYTES_PER_ELEMENT===1,P=(e,t,n="")=>{let o=xa(e),i=e?.length,a=t!==void 0;if(!o||a&&i!==t){let s=n&&`"${n}" `,r=a?` of length ${t}`:"",c=o?`length=${i}`:`type=${typeof e}`,l=s+"expected Uint8Array"+r+", got "+c;throw o?new RangeError(l):new TypeError(l)}return e},rt=e=>new Uint8Array(e),Vt=e=>Uint8Array.from(e),Io=(e,t)=>e.toString(16).padStart(t,"0"),Bo=e=>Array.from(P(e)).map(t=>Io(t,2)).join(""),W={_0:48,_9:57,A:65,F:70,a:97,f:102},Lo=e=>{if(e>=W._0&&e<=W._9)return e-W._0;if(e>=W.A&&e<=W.F)return e-(W.A-10);if(e>=W.a&&e<=W.f)return e-(W.a-10)},Do=e=>{let t="hex invalid";if(!ya(e))return z(t);let n=e.length,o=n/2;if(n%2)return z(t);let i=rt(o);for(let a=0,s=0;a<o;a++,s+=2){let r=Lo(e.charCodeAt(s)),c=Lo(e.charCodeAt(s+1));if(r===void 0||c===void 0)return z(t);i[a]=r*16+c}return i},Ro=()=>globalThis?.crypto,wa=()=>Ro()?.subtle??z("crypto.subtle must be defined, consider polyfill"),Ce=(...e)=>{let t=0;for(let i of e)t+=P(i).length;let n=rt(t),o=0;return e.forEach(i=>{n.set(i,o),o+=i.length}),n},va=(e=fe)=>Ro().getRandomValues(rt(e)),at=BigInt,Q=(e,t,n,o="bad number: out of range")=>{if(!ba(e))throw new TypeError(o);if(t<=e&&e<n)return e;throw new RangeError(o)},T=(e,t=it)=>{let n=e%t;return n>=0n?n:t+n},So=(1n<<255n)-1n,g=e=>{e<0n&&z("negative coordinate");let t=(e>>255n)*19n+(e&So);return t=(t>>255n)*19n+(t&So),t%it},No=e=>T(e,ot),Ea=(e,t)=>{(e===0n||t<=0n)&&z("no inverse n="+e+" mod="+t);let n=T(e,t),o=t,i=0n,a=1n,s=1n,r=0n;for(;n!==0n;){let c=o/n,l=o%n,d=i-s*c,u=a-r*c;o=n,n=l,i=s,a=r,s=d,r=u}return o===1n?T(i,t):z("no inverse")},Po=e=>{let t=_a[e];return typeof t!="function"&&z("hashes."+e+" not set"),t},Ho=e=>P(e,64,"digest"),Yt=e=>e instanceof te?e:z("Point expected"),Zt=2n**256n,te=class e{static BASE;static ZERO;X;Y;Z;T;constructor(t,n,o,i){let a=Zt;this.X=Q(t,0n,a),this.Y=Q(n,0n,a),this.Z=Q(o,1n,a),this.T=Q(i,0n,a),Object.freeze(this)}static CURVE(){return zo}static fromAffine(t){return new e(t.x,t.y,1n,g(t.x*t.y))}static fromBytes(t,n=!1){let o=$t,i=Vt(P(t,fe)),a=t[31];i[31]=a&-129;let s=jo(i);Q(s,0n,n?Zt:it);let c=g(s*s),l=T(c-1n),d=g(o*c+1n),{isValid:u,value:f}=Ca(l,d);u||z("bad point: y not sqrt");let p=(f&1n)===1n,m=(a&128)!==0;return!n&&f===0n&&m&&z("bad point: x==0, isLastByteOdd"),m!==p&&(f=T(-f)),new e(f,s,1n,g(f*s))}static fromHex(t,n){return e.fromBytes(Do(t),n)}get x(){return this.toAffine().x}get y(){return this.toAffine().y}assertValidity(){let t=Kt,n=$t,o=this;if(o.is0())return z("bad point: ZERO");let{X:i,Y:a,Z:s,T:r}=o,c=g(i*i),l=g(a*a),d=g(s*s),u=g(d*d),f=g(c*t),p=g(d*(f+l)),m=T(u+g(n*g(c*l)));if(p!==m)return z("bad point: equation left != right (1)");let y=g(i*a),x=g(s*r);return y!==x?z("bad point: equation left != right (2)"):this}equals(t){let{X:n,Y:o,Z:i}=this,{X:a,Y:s,Z:r}=Yt(t),c=g(n*r),l=g(a*i),d=g(o*r),u=g(s*i);return c===l&&d===u}is0(){return this.equals(ee)}negate(){return new e(T(-this.X),this.Y,this.Z,T(-this.T))}double(){let{X:t,Y:n,Z:o}=this,i=Kt,a=g(t*t),s=g(n*n),r=g(2n*o*o),c=g(i*a),l=T(t+n),d=T(g(l*l)-a-s),u=T(c+s),f=T(u-r),p=T(c-s),m=g(d*f),y=g(u*p),x=g(d*p),h=g(f*u);return new e(m,y,h,x)}add(t){let{X:n,Y:o,Z:i,T:a}=this,{X:s,Y:r,Z:c,T:l}=Yt(t),d=Kt,u=$t,f=g(n*s),p=g(o*r),m=g(g(a*u)*l),y=g(i*c),x=T(g(T(n+o)*T(s+r))-f-p),h=T(y-m),w=T(y+m),S=T(p-g(d*f)),D=g(x*h),he=g(w*S),K=g(x*S),be=g(h*w);return new e(D,he,be,K)}subtract(t){return this.add(Yt(t).negate())}multiply(t,n=!0){if(!n&&t===0n||(Q(t,1n,ot),!n&&this.is0()))return ee;if(t===1n)return this;if(this.equals(ne))return Ba(t).p;let o=ee,i=ne;for(let a=this;t>0n;a=a.double(),t>>=1n)t&1n?o=o.add(a):n&&(i=i.add(a));return o}multiplyUnsafe(t){return this.multiply(t,!1)}toAffine(){let{X:t,Y:n,Z:o}=this;if(this.equals(ee))return{x:0n,y:1n};let i=Ea(o,it);g(o*i)!==1n&&z("invalid inverse");let a=g(t*i),s=g(n*i);return{x:a,y:s}}toBytes(){let{x:t,y:n}=this.toAffine(),o=Fo(n);return o[31]|=t&1n?128:0,o}toHex(){return Bo(this.toBytes())}clearCofactor(){return this.multiply(at(ga),!1)}isSmallOrder(){return this.clearCofactor().is0()}isTorsionFree(){let t=this.multiply(ot/2n,!1).double();return ot%2n&&(t=t.add(this)),t.is0()}},ne=new te(Co,To,1n,T(Co*To)),ee=new te(0n,1n,1n,0n);te.BASE=ne;te.ZERO=ee;Fo=e=>Do(Io(Q(e,0n,Zt),64)).reverse(),jo=e=>at("0x"+Bo(Vt(P(e)).reverse())),N=(e,t)=>{let n=e;for(;t-- >0n;)n=g(n*n);return n},ka=e=>{let t=g(e*e),n=g(t*e),o=g(N(n,2n)*n),i=g(N(o,1n)*e),a=g(N(i,5n)*i),s=g(N(a,10n)*a),r=g(N(s,20n)*s),c=g(N(r,40n)*r),l=g(N(c,80n)*c),d=g(N(l,80n)*c),u=g(N(d,10n)*a);return{pow_p_5_8:g(N(u,2n)*e),b2:n}},Ao=0x2b8324804fc1df0b2b4d00993dfbd7a72f431806ad2fe478c4ee1b274a0ea0b0n,Ca=(e,t)=>{let n=g(t*g(t*t)),o=g(g(n*n)*t),i=ka(g(e*o)).pow_p_5_8,a=g(e*g(n*i)),s=g(t*g(a*a)),r=a,c=g(a*Ao),l=s===e,d=s===T(-e),u=s===T(-e*Ao);return l&&(a=r),(d||u)&&(a=c),(T(a)&1n)===1n&&(a=T(-a)),{isValid:l||d,value:a}},Gt=e=>No(jo(e)),Xt=(...e)=>Promise.resolve(Po("sha512Async")(Ce(...e))).then(Ho),Ta=(...e)=>Ho(Po("sha512")(Ce(...e))),Oo=e=>{let t=Vt(e),n=t.slice(0,32);n[0]&=248,n[31]&=127,n[31]|=64;let o=t.slice(32,64),i=Gt(n),a=ne.multiply(i),s=a.toBytes();return{head:n,prefix:o,scalar:i,point:a,pointBytes:s}},Jt=e=>Xt(P(e,fe)).then(Oo),La=e=>Oo(Ta(P(e,fe))),Qt=e=>Jt(e).then(t=>t.pointBytes),Sa=e=>Xt(e.hashable).then(e.finish),Aa=(e,t,n)=>{let{pointBytes:o,scalar:i}=e,a=Gt(t),s=ne.multiply(a).toBytes();return{hashable:Ce(s,o,n),finish:l=>{let d=No(a+Gt(l)*i);return P(Ce(s,Fo(d)),64)}}},Uo=async(e,t)=>{let n=P(e),o=await Jt(t),i=await Xt(o.prefix,n);return Sa(Aa(o,i,n))},_a={sha512Async:async e=>{let t=wa(),n=Ce(e);return rt(await t.digest("SHA-512",n.buffer))},sha512:void 0},Ma=e=>(e=e===void 0?va(fe):e,P(e,fe)),Wo=Object.freeze({getExtendedPublicKeyAsync:Jt,getExtendedPublicKey:La,randomSecretKey:Ma}),st=8,za=256,Ko=Math.ceil(za/st)+1,qt=2**(st-1),Ia=()=>{let e=[],t=ne,n=t;for(let o=0;o<Ko;o++){n=t,e.push(n);for(let i=1;i<qt;i++)n=n.add(t),e.push(n);t=n.double()}return e},Mo=(e,t)=>{let n=t.negate();return e?n:t},Ba=e=>{let t=_o||(_o=Ia()),n=ee,o=ne,i=2**st,a=i,s=at(i-1),r=at(st);for(let c=0;c<Ko;c++){let l=Number(e&s);e>>=r,l>qt&&(l-=a,e+=1n);let d=c*qt,u=d,f=d+Math.abs(l)-1,p=c%2!==0,m=l<0;l===0?o=o.add(Mo(p,t[u])):n=n.add(Mo(m,t[f]))}return e!==0n&&z("invalid wnaf"),{p:n,f:o}}});function en(e){let t="";for(let n of e)t+=String.fromCharCode(n);return btoa(t).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"")}function Ra(e){let t=e.length%4===0?"":"=".repeat(4-e.length%4),n=(e+t).replace(/-/g,"+").replace(/_/g,"/"),o=atob(n),i=new Uint8Array(o.length);for(let a=0;a<o.length;a++)i[a]=o.charCodeAt(a);return i}function Na(e,t){return{kty:"OKP",crv:"Ed25519",x:en(t),d:en(e),key_ops:["sign"],ext:!0}}function Pa(e){return{kty:"OKP",crv:"Ed25519",x:en(e),key_ops:["verify"],ext:!0}}function Ha(e){if(e.kty!=="OKP"||e.crv!=="Ed25519"||!e.d)throw new Error("Invalid Ed25519 private JWK");return Ra(e.d)}async function Fa(){if(me)return me;let t=(await chrome.storage.local.get(Te))[Te];if(t?.priv&&t?.pub){let s=Ha(t.priv),r=await Qt(s);return me={privBytes:s,pubBytes:r,pubJwk:t.pub},me}let n=Wo.randomSecretKey(),o=await Qt(n),i=Pa(o),a=Na(n,o);return await chrome.storage.local.set({[Te]:{priv:a,pub:i}}),me={privBytes:n,pubBytes:o,pubJwk:i},me}async function Yo(e){let{privBytes:t}=await Fa();return Uo(e,t)}async function Zo(){let t=(await chrome.storage.local.get(Te))[Te];return!!(t?.priv&&t?.pub)}var Te,me,Go=_(()=>{"use strict";$o();Te="saw_keypair_jwk";me=null});function ja(e){return Array.from(e).map(t=>t.toString(16).padStart(2,"0")).join("")}function Oa(e){return JSON.stringify(e,Object.keys(e).sort())}async function qo(e,t){if((await chrome.storage.local.get("saw_installation_id")).saw_installation_id&&!await Zo()){await chrome.storage.local.set({saw_reenroll_required:!0});try{chrome.action?.setBadgeText?.({text:"!"}),chrome.action?.setBadgeBackgroundColor?.({color:"#dc2626"})}catch{}throw new tn}let o=new TextEncoder().encode(`${t}:${Oa(e)}`),i=await Yo(o);return ja(i)}var tn,Vo=_(()=>{"use strict";Go();tn=class extends Error{constructor(){super("re_enroll_required"),this.name="ReEnrollRequiredError"}}});var ei={};ci(ei,{AUDIT_ALARM_NAME:()=>nn,flushAuditQueue:()=>Qo,initAuditService:()=>Za,queueAuditEvent:()=>Ya});function Le(){return(typeof chrome<"u"?chrome:globalThis.browser)?.storage?.local??null}function Wa(){return(typeof chrome<"u"?chrome:globalThis.browser)??null}async function Ka(){try{let e=Le();return e&&(await e.get("orgId"))?.orgId||""}catch{return""}}async function $a(){try{let e=Le();return e&&(await e.get("ai_safety_analytics_settings"))?.ai_safety_analytics_settings?.extensionId||""}catch{return""}}async function Jo(){try{let e=Le();if(!e)return!1;let n=(await e.get("ai_safety_org_policy"))?.ai_safety_org_policy;return n?.policy&&typeof n.policy.analytics_enabled=="boolean"?n.policy.analytics_enabled:(await e.get("sanitize_settings"))?.sanitize_settings?.analytics_enabled!==!1}catch{return!1}}async function Ya(e,t,n){try{if(!await Jo())return;let o=Le();if(!o||(await o.get("saw_org_suspended"))?.saw_org_suspended)return;let s=(await o.get(pe))?.[pe]??[],r=Date.now(),c=s.filter(l=>r-l.timestamp<Ua);c.push({pii_type:e,action:t,platform:n??window?.location?.hostname??"unknown",timestamp:r}),await o.set({[pe]:c}),c.length>=on&&await Qo()}catch{}}async function Qo(){if(Xo)try{if(!await Jo())return;let e=Le();if(!e)return;let n=(await e.get(pe))?.[pe]??[];if(n.length===0)return;let o=n.slice(0,on),i=n.slice(on),[a,s]=await Promise.all([$a(),Ka()]);if(!a)return;let r=Date.now(),c={installationId:a,orgId:s||null,events:o.map(m=>({pii_type:m.pii_type,action:m.action,platform:m.platform,timestamp:m.timestamp}))},d={"Content-Type":"application/json","X-Signature":await qo(c,r),"X-Timestamp":r.toString()},u=new AbortController,f=setTimeout(()=>u.abort(),1e4),p=await fetch(Xo,{method:"POST",headers:d,body:JSON.stringify(c),signal:u.signal,mode:"cors",credentials:"omit"});clearTimeout(f),(p.ok||p.status===404||p.status===503)&&await e.set({[pe]:i})}catch{}}function Za(){let e=Wa();e?.alarms&&e.alarms.get(nn,t=>{t||e.alarms.create(nn,{periodInMinutes:.5})})}var Xo,nn,pe,on,Ua,ti=_(()=>{"use strict";Vo();kt();Xo=Et?Et.replace("/analytics","/audit-event"):"",nn="audit_flush",pe="saw_audit_queue",on=20,Ua=1440*60*1e3});Re();ye();G();var xe=new WeakMap,Ue=new WeakMap;function Un(e){let t=[],n=new RegExp(C.crisis.source,C.crisis.flags),o;for(;(o=n.exec(e))!==null;)t.push({text:o[0],start:o.index,end:o.index+o[0].length});return t}function On(e,t){return t.some(n=>n.text.toLowerCase()===e.text.toLowerCase()&&Math.abs(n.start-e.start)<30)}function Wn(e){return xe.get(e)||[]}function Ii(e,t){document.getElementById("ai-safety-crisis-modal")?.remove();let n=document.createElement("div");n.id="ai-safety-crisis-modal";let o=document.createElement("style");o.textContent=`
    @font-face {
      font-family: 'Inter';
      font-style: normal;
      font-weight: 100 900;
      font-display: swap;
      src: url('${chrome.runtime.getURL("fonts/InterVariable.woff2")}') format('woff2-variations');
    }
    #ai-safety-crisis-modal {
      position: fixed !important;
      z-index: 2147483647 !important;
      left: 0; top: 0; width: 100vw; height: 100vh;
      background: rgba(0, 0, 0, 0.50);
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 16px;
    }
    #ai-safety-crisis-box {
      background: #fff;
      border-radius: 20px;
      box-shadow: 0 8px 40px rgba(0,0,0,0.20);
      padding: 32px;
      max-width: 580px;
      width: 100%;
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
      position: relative;
      max-height: 90vh;
      overflow-y: auto;
    }
    #ai-safety-crisis-logo {
      display: flex;
      align-items: center;
      margin-bottom: 24px;
    }
    #ai-safety-crisis-logo svg {
      height: 42px;
      width: auto;
      margin-left: -10px;
    }
    #ai-safety-crisis-close {
      position: absolute;
      top: 24px;
      right: 24px;
      width: 32px;
      height: 32px;
      border: none;
      background: transparent;
      cursor: pointer;
      padding: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 6px;
      transition: background-color 0.2s;
      color: #6b7280;
      font-size: 24px;
      line-height: 1;
    }
    #ai-safety-crisis-close:hover {
      background-color: #f3f4f6;
      color: #374151;
    }
    #ai-safety-crisis-box h1 {
      font-size: 24px;
      font-weight: 600;
      color: #1f2937;
      margin: 0 0 16px 0;
      line-height: 1.3;
      font-weight: 300;
    }
    #ai-safety-crisis-box .crisis-description {
      font-size: 15px;
      color: #6b7280;
      line-height: 1.6;
      margin-bottom: 20px;
      font-weight: 300;
    }
    #ai-safety-crisis-info-box {
      background: linear-gradient(135deg, #5b21b6 0%, #a855f7 100%);
      border-radius: 16px;
      padding: 20px;
      display: flex;
      align-items: flex-start;
      gap: 16px;
      margin-bottom: 24px;
    }
    #ai-safety-crisis-info-box .icon {
      flex-shrink: 0;
      width: auto;
      height: 62px;
    }
    #ai-safety-crisis-info-box .icon svg {
      width: 100%;
      height: 100%;
      fill: white;
    }
    #ai-safety-crisis-info-box .text {
      color: white;
      font-size: 14px;
      line-height: 1.6;
      font-weight: 300;
    }
    #ai-safety-crisis-box h2 {
      font-size: 16px;
      font-weight: 600;
      color: #1f2937;
      margin: 0 0 12px 0;
      font-weight: 300px;
    }
    #ai-safety-crisis-box ul {
      list-style: none;
      padding: 0;
      margin: 0 0 24px 0;
    }
    #ai-safety-crisis-box ul li {
      font-size: 14px;
      color: #4b5563;
      line-height: 1.6;
      margin-bottom: 0px;
      padding-left: 0;
      font-weight: 300;
    }
    #ai-safety-crisis-box ul li::before {
      content: "\u2022 ";
      color: #6b7280;
      font-weight: bold;
      margin-right: 8px;
    }
    #ai-safety-crisis-box .crisis-link {
      display: flex;
      align-items: center;
      gap: 6px;
      color: #5b21b6;
      text-decoration: none;
      font-weight: 500;
      margin-left: 16px;
      font-size: 14px;
    }
    #ai-safety-crisis-box .crisis-link:hover {
      text-decoration: underline;
    }
    #ai-safety-crisis-buttons {
      display: flex;
      gap: 12px;
      margin-top: 24px;
    }
    #ai-safety-crisis-buttons button {
      flex: 1;
      padding: 14px 20px;
      font-size: 15px;
      font-weight: 600;
      border: 1px solid #7C51DC;
      border-radius: 20px;
      cursor: pointer;
      transition: all 0.2s;
    }
    #ai-safety-crisis-buttons .btn-primary {
      background: transparent;
      color: #454545;
    }
    #ai-safety-crisis-buttons .btn-primary:hover {
      background: #f3f4f6;
    }
    #ai-safety-crisis-buttons .btn-secondary {
      background: transparent;
      color: #454545;
      border-color: #5b21b6;
      border: 0px;
    }
    #ai-safety-crisis-buttons .btn-secondary:hover {
      background: #f3f4f6;
    }
    @media (max-width: 640px) {
      #ai-safety-crisis-box {
        padding: 24px;
      }
      #ai-safety-crisis-buttons {
        flex-direction: column;
      }
    }
  `,n.appendChild(o);let i=document.createElement("div");i.id="ai-safety-crisis-box",i.setAttribute("role","alert"),i.setAttribute("aria-live","assertive"),i.innerHTML=`
    <div id="ai-safety-crisis-logo">
      <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 699.1 171.67">
        <defs>
          <linearGradient id="crisis-grad-1" x1="76.17" y1="89.78" x2="172.31" y2="89.78" gradientUnits="userSpaceOnUse">
            <stop offset="0" stop-color="#06cbd9"/>
            <stop offset=".16" stop-color="#16b8dd"/>
            <stop offset=".73" stop-color="#4b7aea"/>
            <stop offset="1" stop-color="#6062f0"/>
          </linearGradient>
          <linearGradient id="crisis-grad-2" x1="40.31" y1="79.45" x2="138.42" y2="79.45" gradientUnits="userSpaceOnUse">
            <stop offset="0" stop-color="#3e31f3"/>
            <stop offset=".81" stop-color="#ea34bb"/>
            <stop offset="1" stop-color="#ff0dbb"/>
          </linearGradient>
          <linearGradient id="crisis-grad-3" x1="144.88" y1="105.71" x2="180.28" y2="105.71" xlink:href="#crisis-grad-2"/>
        </defs>
        <path fill="url(#crisis-grad-1)" d="M155.08,52.27c3.59-1,16.96,12.46,17.21,15.06.09.98-.08,1.89-.61,2.73l-56.98,56.45c-.77.41-1.63.84-2.52.81-2.91-.08-31.17-30.62-35.63-35.13-2.97-3.76,12.52-17.46,14.38-17.66,6.51-.68,18.98,18.5,22.25,17.92l41.91-40.18Z"/>
        <path fill="url(#crisis-grad-2)" d="M123,76.08l15.41-14.28c-9.66-11.26-17.82-20.75-20.15-23.48-2-2.33-4.89-3.66-7.97-3.66s-5.96,1.33-7.97,3.66c-3.38,3.93-18.88,21.99-33.54,39.07-7.33,8.54-14.45,16.83-19.74,22.99-2.64,3.08-4.83,5.62-6.35,7.4-.76.89-1.36,1.58-1.77,2.06-.41.47-.62.72-.62.73l15.93,13.68s36.86-42.94,54.05-62.96c3.56,4.15,7.96,9.27,12.71,14.8Z"/>
        <path fill="url(#crisis-grad-3)" d="M160.21,87.18l-15.32,14.39c10.84,12.63,19.46,22.67,19.46,22.67l15.93-13.68s-8.94-10.42-20.07-23.39Z"/>
        <text font-family="AvenirNext-Bold, 'Avenir Next'" font-size="68.71" font-weight="700" transform="translate(218.33 109.62)">
          <tspan fill="#402bbc" x="0" y="0">SAFE </tspan>
          <tspan fill="#ba24ba" x="194.79" y="0">AI </tspan>
          <tspan fill="#402bbc" x="287.21" y="0">WAY</tspan>
        </text>
      </svg>
    </div>
    <button id="ai-safety-crisis-close" aria-label="Sluiten">\xD7</button>
    <h1>Even opletten, dit gaat over je gevoelens.</h1>
    <p class="crisis-description">
      Je typt iets dat persoonlijk en kwetsbaar is.<br>
      AI-systemen zijn niet bedoeld om hulp te bieden bij mentale gezondheid,
      en de info die je deelt kan door sommige systemen worden bewaard.
    </p>
    <div id="ai-safety-crisis-info-box">
      <div class="icon">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640">
          <path d="M341.4 104.4C352.5 89.1 370.2 80 389.1 80C421.6 80 448 106.4 448 138.9C448 171 428.2 200 405.9 225.4C381.4 253.2 351.9 277.2 332.1 291.9C324.8 297.4 315.1 297.4 307.7 291.9C288 277.2 258.4 253.3 233.9 225.4C211.6 200.1 191.9 171 191.9 138.9C191.9 106.4 218.3 80 250.8 80C269.7 80 287.4 89.1 298.5 104.4L313.5 125C315 127.1 317.4 128.3 320 128.3C322.6 128.3 325 127.1 326.5 125L341.4 104.4zM389.1 64C365.1 64 342.5 75.5 328.4 95L320 106.7L311.6 95C297.5 75.5 274.9 64 250.9 64C209.5 64 176 97.5 176 138.9C176 177.3 199.5 210.3 222 235.9C247.5 264.9 278.1 289.7 298.2 304.6C311.2 314.3 328.7 314.3 341.7 304.6C361.8 289.6 392.4 264.9 417.9 235.9C440.4 210.3 463.9 177.3 463.9 138.9C463.9 97.5 430.4 64 389 64zM96 176C96 149.5 74.5 128 48 128C21.5 128 0 149.5 0 176L0 408.2C0 435.8 11 462.2 30.5 481.7L122.4 573.6C125.5 576.7 130.6 576.7 133.7 573.6C136.8 570.5 136.8 565.4 133.7 562.3L41.8 470.5C25.3 454 16 431.6 16 408.2L16 176C16 158.3 30.3 144 48 144C65.7 144 80 158.3 80 176L80 323C80 343.7 88.2 363.6 102.9 378.2C109.9 385.2 135 410.3 178.4 453.7L178.4 453.7L186.4 461.7C189.5 464.8 194.6 464.8 197.7 461.7C200.8 458.6 200.8 453.5 197.7 450.4L189.7 442.4L189.7 442.4L133.8 386.5L133.8 386.5C123.2 375.9 122.5 358.9 132.3 347.4C143.2 334.7 162.6 333.9 174.5 345.8L267.3 438.5C280.6 451.8 288.1 469.9 288.1 488.8L288.1 568C288.1 572.4 291.7 576 296.1 576C300.5 576 304.1 572.4 304.1 568L304.1 488.8C304.1 465.7 294.9 443.5 278.6 427.2L185.8 334.4C167.4 316 137.1 317.1 120.2 336.9C114 344.1 110.5 352.8 109.6 361.6C100.9 350.7 96.1 337 96.1 322.9L96.1 175.9zM592 128C565.5 128 544 149.5 544 176L544 323C544 337.1 539.2 350.8 530.5 361.7C529.6 352.9 526.1 344.2 519.9 337C502.9 317.2 472.7 316 454.3 334.5L361.6 427.3C345.3 443.6 336.1 465.8 336.1 488.9L336.1 568.1C336.1 572.5 339.7 576.1 344.1 576.1C348.5 576.1 352.1 572.5 352.1 568.1L352.1 488.9C352.1 470 359.6 451.9 372.9 438.6L465.7 345.9C477.5 334.1 497 334.8 507.9 347.5C517.7 358.9 517 375.9 506.4 386.6L506.4 386.6L450.5 442.5L450.5 442.5L442.5 450.5C439.4 453.6 439.4 458.7 442.5 461.8C445.6 464.9 450.7 464.9 453.8 461.8L461.8 453.8C505.1 410.5 530.3 385.3 537.3 378.3C551.9 363.7 560.2 343.8 560.2 323.1L560.2 176.1C560.2 158.4 574.5 144.1 592.2 144.1C609.9 144.1 624.2 158.4 624.2 176.1L624.2 408.3C624.2 431.6 614.9 454 598.4 470.5L506.5 562.4C503.4 565.5 503.4 570.6 506.5 573.7C509.6 576.8 514.7 576.8 517.8 573.7L609.7 481.8C629.2 462.3 640.2 435.8 640.2 408.3L640 176C640 149.5 618.5 128 592 128z"/>
        </svg>
      </div>
      <div class="text">
        Je bent niet alleen.<br>
        Maar voor dingen zoals dit deel je beter met iemand die je echt kan helpen, niet met een AI.
      </div>
    </div>
    <h2>Wat kan je nu doen?</h2>
    <ul>
      <li>Praat met iemand die je vertrouwt (vriend, ouder, vertrouwenspersoon)</li>
      <li>Als je je echt slecht voelt:</li>
    </ul>
    <a href="https://www.awel.be" target="_blank" rel="noopener noreferrer" class="crisis-link">
      \u{1F449} <span>www.awel.be</span> <span style="color: #6b7280;">(gratis & anoniem chatten)</span>
    </a>
    <br>
    <a href="https://www.tele-onthaal.be" target="_blank" rel="noopener noreferrer" class="crisis-link">
      \u{1F449} <span>www.tele-onthaal.be</span> <span style="color: #6b7280;">(telefoon of chat)</span>
    </a>
    <div id="ai-safety-crisis-buttons">
      <button class="btn-primary" id="crisis-continue-btn">Toch versturen - anoniem</button>
    </div>
  `,n.appendChild(i),document.documentElement.appendChild(n),setTimeout(()=>document.getElementById("crisis-continue-btn")?.focus(),100);let a=!1,s=r=>{a||(a=!0,n.remove(),r==="sanitize"?e?.():t?.())};document.getElementById("ai-safety-crisis-close")?.addEventListener("click",()=>s("dismiss")),document.getElementById("crisis-continue-btn")?.addEventListener("click",()=>s("sanitize")),n.addEventListener("keydown",r=>{r.key==="Escape"&&s("dismiss")}),n.addEventListener("click",r=>{r.target===n&&s("dismiss")})}function Tt(e,t,n,o,i=!1,a){if(!n||!o||e&&Ue.get(e))return;let s=Un(t);if(s.length!==0){if(i&&e){let r=xe.get(e)||[];if(s.filter(l=>!On(l,r)).length===0)return}e&&Ue.set(e,!0),Ii(()=>{e&&Ue.set(e,!1),i&&e&&(Bi(e),a?.())},()=>{if(e&&Ue.set(e,!1),i&&e){let r=xe.get(e)||[];for(let c of s)On(c,r)||r.push({text:c.text,start:c.start});xe.set(e,r)}}),Hn(window.location.hostname).catch(()=>{})}}function Bi(e){let t,n=e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement;if(n)t=e.value;else if(e.isContentEditable)t=e.innerText||e.textContent||"";else return;let o=Un(t);if(o.length===0)return;let i=t,a=[...o].sort((s,r)=>r.start-s.start);for(let s of a)i=i.slice(0,s.start)+E.crisis+i.slice(s.end);if(n){let s=e,r=s.selectionStart??s.value.length;s.value=i;let c=Math.min(r,i.length);try{s.setSelectionRange(c,c)}catch{}s.dispatchEvent(new Event("input",{bubbles:!0}))}else e.isContentEditable&&(e.textContent=i,e.dispatchEvent(new Event("input",{bubbles:!0})));xe.delete(e)}G();var Lt=!1;function Di(){if(Lt)return;Lt=!0,document.getElementById("ai-safety-jailbreak-modal")?.remove();let e=document.createElement("div");e.id="ai-safety-jailbreak-modal";let t=document.createElement("style");t.textContent=`
    #ai-safety-jailbreak-modal {
      position: fixed !important;
      z-index: 2147483647 !important;
      left: 0; top: 0; width: 100vw; height: 100vh;
      background: rgba(0, 0, 0, 0.65);
      display: flex;
      align-items: center;
      justify-content: center;
    }
    #ai-safety-jailbreak-box {
      background: #fff;
      border-radius: 16px;
      box-shadow: 0 8px 40px rgba(0,0,0,0.25);
      padding: 28px;
      max-width: 480px;
      font-family: system-ui, -apple-system, sans-serif;
      position: relative;
    }
    #ai-safety-jailbreak-box .jailbreak-icon {
      font-size: 52px;
      text-align: center;
      margin-bottom: 16px;
    }
    #ai-safety-jailbreak-box h2 {
      font-size: 20px;
      font-weight: 700;
      color: #dc2626;
      margin: 0 0 16px 0;
      text-align: center;
      line-height: 1.3;
    }
    #ai-safety-jailbreak-box button {
      width: 100%;
      padding: 14px;
      font-size: 16px;
      font-weight: 600;
      border: none;
      border-radius: 10px;
      cursor: pointer;
      background: #dc2626;
      color: white;
      transition: background 0.2s;
      margin-top: 8px;
    }
    #ai-safety-jailbreak-box button:hover {
      background: #b91c1c;
    }
  `,e.appendChild(t);let n=document.createElement("div");n.id="ai-safety-jailbreak-box",n.setAttribute("role","alert"),n.setAttribute("aria-live","assertive"),n.innerHTML=`
    <div class="jailbreak-icon">\u{1F6E1}\uFE0F</div>
    <h2>Jailbreak prompt geblokkeerd door AI Safety</h2>
    <button id="jailbreak-ok-btn">Ik begrijp het</button>
  `,e.appendChild(n),document.documentElement.appendChild(e),setTimeout(()=>document.getElementById("jailbreak-ok-btn")?.focus(),100);let o=()=>{e.remove(),setTimeout(()=>{Lt=!1},1e4)};document.getElementById("jailbreak-ok-btn")?.addEventListener("click",o),e.addEventListener("keydown",i=>{i.key==="Escape"&&o()}),e.addEventListener("click",i=>{i.target===e&&o()})}function St(e,t,n){!t||!n||(C.jailbreak.lastIndex=0,C.jailbreak.test(e)&&(Di(),Fn(window.location.hostname).catch(()=>{})))}function k(e){return(e==null?"":String(e)).toLowerCase().trim()}function We(e){return e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement}function j(e){if(e.isContentEditable===!0)return!0;let t=e.getAttribute?.("contenteditable");return t!==null&&t!=="false"&&t!=="inherit"}function we(e){let t=e;for(;t;){if(t.nodeType===Node.ELEMENT_NODE){let n=t;if(We(n)||j(n))return n}t=t.parentNode}return null}function Ri(e){if(!(e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement))return!1;let t=k(e.type);if(t==="password")return!0;let n=k(e.id),o=k(e.name),i=k(e.placeholder),a=k(e.getAttribute?.("aria-label")),s=["login","user","username","gebruikersnaam","signin","sign-in","aanmelden","inloggen"],r=["email","e-mail"],c=["otp","2fa","code","verificatie","authenticator"],l=t==="email"||r.some(f=>n.includes(f)||o.includes(f)||i.includes(f)||a.includes(f)),d=s.some(f=>n.includes(f)||o.includes(f)||i.includes(f)||a.includes(f)),u=c.some(f=>n.includes(f)||o.includes(f)||i.includes(f)||a.includes(f));return d||l||u}var Ni=["contact","contactform","contact-form","support","help","offerte","aanvraag","klacht","vraag"];function Pi(e){let t=k(e.id),n=k(e.name),o=k(e.className),i=k(e.getAttribute("aria-label")),a=k(e.getAttribute("action")),s=["login","signin","sign-in","aanmelden","inloggen","auth","authenticate"];if([t,n,o,i,a].some(l=>s.some(d=>l.includes(d)))||e.querySelector('input[type="password"]'))return!0;let r=e.querySelector('input[name*="user" i], input[id*="user" i], input[placeholder*="user" i], input[aria-label*="user" i]'),c=e.querySelector('input[type="email"], input[name*="email" i], input[id*="email" i]');return!!(r&&(c||e.querySelector('input[type="password"]')))}function Hi(e){let t=k(e.id),n=k(e.name),o=k(e.className),i=k(e.getAttribute("aria-label")),a=k(e.getAttribute("action"));return[t,n,o,i,a].some(l=>Ni.some(d=>l.includes(d)))?!0:e.querySelector('textarea[name*="message" i], textarea[id*="message" i], textarea[name*="bericht" i], textarea[id*="bericht" i]')?!!e.querySelector('input[name*="name" i], input[id*="name" i], input[placeholder*="naam" i], input[placeholder*="name" i],input[type="tel"], input[name*="phone" i], input[name*="telefoon" i], input[name*="tel" i], input[name*="mobile" i], input[name*="gsm" i],input[type="email"], input[name*="email" i], input[id*="email" i]'):!1}function At(e){return e?Pi(e)||Hi(e):!1}function Fi(e){if(!(e instanceof HTMLInputElement))return!1;if(e.hasAttribute("list"))return!0;let t=k(e.getAttribute("role"));if(t==="combobox"||t==="searchbox"||e.hasAttribute("aria-autocomplete")||e.hasAttribute("aria-activedescendant")||e.getAttribute("aria-haspopup")==="listbox"||e.getAttribute("aria-haspopup")==="true"||e.closest?.('[role="combobox"], [role="listbox"]'))return!0;let n=k(e.id),o=k(e.className),i=k(e.name);return!!["autocomplete","typeahead","combobox","dropdown","select","station","city","stad","gemeente","location","locatie","destination","bestemming","departure","vertrek","arrival","aankomst"].some(s=>n.includes(s)||o.includes(s)||i.includes(s))}function ji(e){if(!(e instanceof HTMLInputElement))return!1;let t=k(e.type);if(t==="date"||t==="datetime-local"||t==="month"||t==="week")return!0;let n=k(e.id),o=k(e.className),i=k(e.name),a=k(e.placeholder),s=k(e.getAttribute?.("aria-label")),r=[n,o,i,a,s];if(["travel","reis","vertrek","aankomst","departure","arrival","return","check-in","checkin","check-out","checkout","booking","boeking","reserv","schedule","planning","agenda","start-date","startdate","end-date","enddate","from-date","fromdate","to-date","todate","outbound","inbound","heenreis","terugreis","datepicker","date-picker","calendar","kalender"].some(u=>r.some(f=>f.includes(u))))return!0;let l=e.closest?.("form");if(l){let u=k(l.id),f=k(l.className),p=k(l.getAttribute("action")),m=[u,f,p];if(["booking","boeking","reserv","search","zoek","travel","reis","ticket","flight","vlucht","train","trein","hotel","car-rental","autoverhuur"].some(x=>m.some(h=>h.includes(x))))return!0}return!!e.closest?.('[class*="booking"], [class*="search"], [class*="travel"], [class*="journey"], [class*="trip"], [class*="reis"], [class*="ticket"]')}function ve(e){if(e instanceof HTMLInputElement){let n=k(e.type);if(n==="password"||n==="hidden"||n==="file"||Ri(e)||Fi(e)||ji(e))return!0}let t=e.closest?.("form");return!!(t&&At(t))}Ye();ye();G();Zn();Ye();function Gn(e,t){let n=e.value,o=e.selectionStart??n.length,i=e.selectionEnd??n.length,a=o,{text:s,newCaret:r}=t(n,a);if(s===n)return;e.value=s;let c=r-a,l=Math.max(0,Math.min(s.length,o+c)),d=Math.max(0,Math.min(s.length,i+c));try{e.setSelectionRange(l,d)}catch{}$e(e)}G();function Vn(e){return e.status==="success"||e.status==="success_via_ocr"}var qn="ai_safety_analytics_settings";async function Xn(){try{let t=(typeof chrome<"u"?chrome:globalThis.browser)?.storage?.local;return t?(await t.get([qn]))?.[qn]?.extensionId??null:null}catch{return null}}function Ki(){return typeof crypto<"u"&&typeof crypto.randomUUID=="function"?crypto.randomUUID():"xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,e=>{let t=Math.random()*16|0;return(e==="x"?t:t&3|8).toString(16)})}function $i(e){if(!e)return null;if(e instanceof Uint8Array)return e;if(e instanceof ArrayBuffer)return new Uint8Array(e);if(typeof e=="object"){let t=Object.keys(e);if(t.length===0)return null;let n=new Uint8Array(t.length);for(let o=0;o<t.length;o++)n[o]=e[String(o)]??0;return n}return null}async function Jn(e,t,n){let o=Ki(),i=e.size,a;try{let r=await e.arrayBuffer();a=new Uint8Array(r)}catch(r){return{status:"failed_other",error:r instanceof Error?r.message:"File read error"}}let s=globalThis.chrome;if(!s?.runtime?.sendMessage)return{status:"failed_other",error:"chrome.runtime.sendMessage niet beschikbaar (geen extensie-context?)"};try{let r=await s.runtime.sendMessage({type:"MASK_PDF",fileBytes:a,filename:e.name,fileType:e.type||"application/pdf",fileSizeBytes:i,installationId:t,hostname:n,requestId:o});if(!r)return{status:"failed_other",error:"No response from background"};if(r.status==="success"||r.status==="success_via_ocr"){let c=$i(r.fileBytes);if(!c||c.byteLength===0)return{status:"failed_other",error:"Lege of corrupte response bytes uit background"};let l=new File([c],r.filename||`sanitized-${o.slice(0,8)}.pdf`,{type:"application/pdf",lastModified:Date.now()});return{status:r.status,via_ocr:!!r.via_ocr,file:l,counts_by_type:r.counts_by_type??{},page_count:r.page_count??0,processing_ms:r.processing_ms??0}}return{status:r.status||"failed_other",error:r.error,page_count:r.page_count}}catch(r){return{status:"failed_other",error:r instanceof Error?r.message:"Message passing error"}}}var Yi=[/(?:^|\.)gemini\.google\.com$/i];function Qn(e){return Yi.some(t=>t.test(e))}function eo(e){let t=URL.createObjectURL(e),n=document.createElement("a");n.href=t,n.download=e.name,n.style.display="none",document.body.appendChild(n),n.click(),document.body.removeChild(n),setTimeout(()=>URL.revokeObjectURL(t),2e3)}var Ze=new WeakSet;function to(e){return Ze.has(e)}function Bt(e,t){try{for(let o of t)Ze.add(o);let n=new DataTransfer;for(let o of t)n.items.add(o);return e.files=n.files,e.dispatchEvent(new Event("input",{bubbles:!0})),e.dispatchEvent(new Event("change",{bubbles:!0})),!0}catch{return!1}}var It=["[xapfileselectordropzone]","[data-dropzone]",".drop-zone",".dropzone",'[role="region"][aria-label*="upload" i]'].join(",");function Zi(e,t){try{for(let r of t)Ze.add(r);let n=new DataTransfer;for(let r of t)n.items.add(r);let o=window.__aiDragX??0,i=window.__aiDragY??0,a=e;if(e instanceof Element){let r=e.closest(It)||document.querySelector(It);r&&(a=r)}else e||(a=document.querySelector(It)??document.body);if(!a)return!1;let s={bubbles:!0,cancelable:!0,composed:!0,dataTransfer:n,clientX:o,clientY:i};return a.dispatchEvent(new DragEvent("dragenter",s)),a.dispatchEvent(new DragEvent("dragover",s)),a.dispatchEvent(new DragEvent("drop",s)),!0}catch{return!1}}function Gi(e){let t=[],n=[e];for(;n.length>0;){let o=n.pop(),i=o.querySelectorAll('input[type="file"]');for(let s of Array.from(i))t.push(s);let a=o.querySelectorAll("*");for(let s of Array.from(a)){let r=s.shadowRoot;r&&n.push(r)}}return t}function qi(e){if(e instanceof Element){let n=e.closest("form");if(n){let o=n.querySelector('input[type="file"]');if(o)return o}}let t=Gi(document);for(let n of t){let o=n.accept||"";if(!o||o.includes("pdf")||o.includes("application")||o==="*/*")return n}return t[0]??null}function no(e,t){for(let o of t)Ze.add(o);if(e&&Zi(e,t))return{delivered:!0,via:"drop-replay"};let n=qi(e);return n&&Bt(n,t)?{delivered:!0,via:"input"}:{delivered:!1,via:"failed"}}var Vi={email:"e-mail",phone:"telefoon",iban:"IBAN",creditcard:"kaartnummer",nationalid:"rijksregister",insz:"INSZ",vat:"BTW",kbo:"KBO",address:"adres",dob_age:"leeftijd/geboortedatum",children:"kinderen",name:"naam",health:"gezondheid",crisis:"crisissignaal",courtcase:"dossier",salary:"salaris"},Xi={queued:"wachten",uploading:"uploaden",processing:"maskeren",done:"klaar",error:"fout"};function oo(e){let t=new Map;for(let h of e)t.set(h,{filename:h,stage:"queued"});let n=null,o=new Promise(h=>{n=h}),i=document.createElement("div");i.id="ai-safety-masking-modal",i.setAttribute("role","dialog"),i.setAttribute("aria-modal","true");let a=document.createElement("style");a.textContent=`
    #ai-safety-masking-modal {
      position: fixed; inset: 0;
      background: rgba(20, 22, 30, 0.55);
      z-index: 2147483646;
      display: flex; align-items: center; justify-content: center;
      font-family: 'Inter', system-ui, -apple-system, sans-serif;
    }
    #ai-safety-masking-modal .box {
      background: #fff; border-radius: 12px;
      box-shadow: 0 20px 60px rgba(0,0,0,0.25);
      width: min(560px, 92vw); max-height: 80vh;
      display: flex; flex-direction: column;
      overflow: hidden;
    }
    #ai-safety-masking-modal .header {
      padding: 18px 22px 12px; border-bottom: 1px solid #eef0f4;
    }
    #ai-safety-masking-modal h2 {
      margin: 0; font-size: 17px; color: #1a1d24;
    }
    #ai-safety-masking-modal .subtitle {
      margin: 4px 0 0; font-size: 13px; color: #6b7280;
    }
    #ai-safety-masking-modal .body {
      padding: 14px 22px; overflow-y: auto; flex: 1;
    }
    #ai-safety-masking-modal .file-row {
      display: flex; align-items: center; gap: 12px;
      padding: 10px 0; border-bottom: 1px solid #f3f4f6;
    }
    #ai-safety-masking-modal .file-row:last-child { border-bottom: none; }
    #ai-safety-masking-modal .file-name {
      flex: 1; font-size: 13px; color: #1a1d24; overflow: hidden;
      text-overflow: ellipsis; white-space: nowrap;
    }
    #ai-safety-masking-modal .stage {
      font-size: 12px; color: #6b7280;
      display: flex; align-items: center; gap: 6px;
    }
    #ai-safety-masking-modal .stage.done { color: #059669; }
    #ai-safety-masking-modal .stage.error { color: #dc2626; }
    #ai-safety-masking-modal .spinner {
      width: 12px; height: 12px; border-radius: 50%;
      border: 2px solid #e5e7eb; border-top-color: #6366f1;
      animation: ai-saw-spin 0.8s linear infinite;
    }
    @keyframes ai-saw-spin { to { transform: rotate(360deg); } }
    #ai-safety-masking-modal .counts {
      font-size: 11px; color: #6b7280; margin-top: 4px;
    }
    #ai-safety-masking-modal .error-msg {
      font-size: 11px; color: #dc2626; margin-top: 4px;
    }
    #ai-safety-masking-modal .footer {
      padding: 14px 22px; border-top: 1px solid #eef0f4;
      display: flex; justify-content: flex-end; gap: 8px;
    }
    #ai-safety-masking-modal button {
      border: none; border-radius: 8px; padding: 9px 16px;
      font-size: 13px; font-weight: 500; cursor: pointer;
      transition: all .15s;
    }
    #ai-safety-masking-modal button.cancel {
      background: #f3f4f6; color: #374151;
    }
    #ai-safety-masking-modal button.cancel:hover { background: #e5e7eb; }
    #ai-safety-masking-modal button.primary {
      background: #6366f1; color: #fff;
    }
    #ai-safety-masking-modal button.primary:hover:not(:disabled) { background: #4f46e5; }
    #ai-safety-masking-modal button.primary:disabled {
      background: #c7d2fe; cursor: not-allowed;
    }
    #ai-safety-masking-modal .privacy {
      font-size: 11px; color: #9ca3af; padding: 0 22px 14px;
    }
  `;let s=document.createElement("div");s.className="box";let r=document.createElement("div");r.className="header",r.innerHTML=`
    <h2>Bestand(en) worden gesaneerd</h2>
    <p class="subtitle">${e.length} PDF${e.length===1?"":"'s"} verwerkt door Safe AI Way \u2014 gevoelige data wordt vervangen door placeholders.</p>
  `;let c=document.createElement("div");c.className="body";let l=document.createElement("p");l.className="privacy",l.textContent="Privacy: het bestand wordt tijdelijk verwerkt, niet opgeslagen. Originele bestand blijft alleen op uw apparaat.";let d=document.createElement("div");d.className="footer";let u=document.createElement("button");u.className="cancel",u.textContent="Annuleren";let f=document.createElement("button");f.className="primary",f.textContent="Doorgaan met gesaneerd bestand",f.disabled=!0,d.append(u,f),s.append(r,c,l,d),i.append(a,s),document.documentElement.appendChild(i);let p=h=>{let w=c.querySelector(`[data-file="${Ji(h.filename)}"]`);w||(w=document.createElement("div"),w.className="file-row",w.setAttribute("data-file",h.filename),c.appendChild(w));let S=Xi[h.stage],D=h.stage==="uploading"||h.stage==="processing",he=h.stage==="done"?"done":h.stage==="error"?"error":"",K="";if(h.stage==="done"&&h.counts){let be=[];for(let[fn,mn]of Object.entries(h.counts))mn>0&&be.push(`${mn} ${Vi[fn]??fn}`);be.length>0?K=`<div class="counts">Gemaskeerd: ${be.join(", ")}</div>`:K='<div class="counts">Geen gevoelige data gevonden.</div>'}else h.stage==="error"&&(K=`<div class="error-msg">${Ge(h.errorMsg??"Onbekende fout")}</div>`);w.innerHTML=`
      <div style="flex:1;min-width:0">
        <div class="file-name">${Ge(h.filename)}</div>
        ${K}
      </div>
      <div class="stage ${he}">
        ${D?'<span class="spinner"></span>':""}
        ${S}
      </div>
    `},m=()=>{let h=Array.from(t.values()),w=h.every(D=>D.stage==="done"||D.stage==="error"),S=h.some(D=>D.stage==="done");f.disabled=!w,w&&(f.textContent=S?"Doorgaan met gesaneerd bestand":"Sluiten")};for(let h of t.values())p(h);u.addEventListener("click",()=>{x(),n?.("cancel")}),f.addEventListener("click",()=>{f.disabled||(x(),n?.("continue"))});let y=!1,x=()=>{y||(y=!0,i.remove())};return{setStage(h,w){let S=t.get(h);S&&(S.stage=w,p(S),m())},setCounts(h,w){let S=t.get(h);S&&(S.counts=w,p(S))},setError(h,w){let S=t.get(h);S&&(S.stage="error",S.errorMsg=w,p(S),m())},awaitClose(){return o},destroy:x}}function Ji(e){return e.replace(/["\\]/g,"\\$&")}function io(e){return new Promise(t=>{let n=document.createElement("div");n.id="ai-safety-manual-prompt",n.setAttribute("role","dialog"),n.setAttribute("aria-modal","true");let o=document.createElement("style");o.textContent=`
      #ai-safety-manual-prompt {
        position: fixed; inset: 0;
        background: rgba(20, 22, 30, 0.55);
        z-index: 2147483646;
        display: flex; align-items: center; justify-content: center;
        font-family: 'Inter', system-ui, -apple-system, sans-serif;
      }
      #ai-safety-manual-prompt .box {
        background: #fff; border-radius: 12px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.25);
        width: min(480px, 92vw);
        padding: 22px 24px 18px;
        display: flex; flex-direction: column;
      }
      #ai-safety-manual-prompt h2 {
        margin: 0; font-size: 16px; color: #1a1d24;
      }
      #ai-safety-manual-prompt .reason {
        margin: 6px 0 14px; font-size: 13px; color: #6b7280; line-height: 1.45;
      }
      #ai-safety-manual-prompt ol {
        margin: 0 0 14px 18px; padding: 0; font-size: 13px; color: #374151; line-height: 1.6;
      }
      #ai-safety-manual-prompt .files {
        background: #f9fafb; border-radius: 8px; padding: 8px 12px;
        font-size: 12px; color: #4b5563; margin-bottom: 14px;
      }
      #ai-safety-manual-prompt .files div {
        padding: 2px 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
      }
      #ai-safety-manual-prompt .footer {
        display: flex; justify-content: flex-end; gap: 8px;
      }
      #ai-safety-manual-prompt button {
        border: none; border-radius: 8px; padding: 9px 16px;
        font-size: 13px; font-weight: 500; cursor: pointer;
        transition: all .15s;
      }
      #ai-safety-manual-prompt button.cancel {
        background: #f3f4f6; color: #374151;
      }
      #ai-safety-manual-prompt button.cancel:hover { background: #e5e7eb; }
      #ai-safety-manual-prompt button.primary {
        background: #6366f1; color: #fff;
      }
      #ai-safety-manual-prompt button.primary:hover { background: #4f46e5; }
    `;let i=document.createElement("div");i.className="box";let a=e.files.map(c=>`<div>${Ge(c.name)}</div>`).join("");i.innerHTML=`
      <h2>Bestand gesaneerd \u2014 handmatige upload nodig</h2>
      <p class="reason">${Ge(e.reason)}</p>
      <ol>
        <li>Klik <strong>"Downloaden"</strong> hieronder om het gesaneerde bestand op te slaan.</li>
        <li>Klik op de <strong>"+"</strong> knop op deze pagina en selecteer het zojuist gedownloade bestand.</li>
      </ol>
      <div class="files">${a}</div>
      <div class="footer">
        <button class="cancel" data-action="cancel">Annuleren</button>
        <button class="primary" data-action="download">Downloaden</button>
      </div>
    `,n.append(o,i),document.documentElement.appendChild(n);let s=!1,r=()=>{s||(s=!0,n.remove())};i.addEventListener("click",c=>{let l=c.target.closest("button[data-action]");if(!l)return;let d=l.getAttribute("data-action");if(d==="download"){for(let u of e.files)e.onDownload(u);r(),t("downloaded")}else d==="cancel"&&(r(),t("cancelled"))}),n.addEventListener("click",c=>{c.target===n&&(r(),t("cancelled"))})})}function Ge(e){return e.replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[t]??t)}function so(e){let t=Array.from(e||[]);return t.length===0?!1:t.every(n=>to(n))}function Rt(e,t){if(!t.addons?.pdf_masking)return[];let n=[];for(let o of Array.from(e||[])){if(!lo(o.name||"",o.type||""))continue;let i=t.pdfs_policy;(i==="warn"||i==="allow")&&n.push(o)}return n}async function ro(e,t,n){let o=Rt(e,t);if(o.length===0)return null;let i=await Xn();if(!i)return null;let a=oo(o.map(p=>p.name)),s=new Map,r=!0,c=[...o],l=[],d=3,u=async p=>{a.setStage(p.name,"uploading");try{a.setStage(p.name,"processing");let m=await Jn(p,i,n);if(Vn(m))s.set(p,m.file),a.setCounts(p.name,m.counts_by_type),a.setStage(p.name,"done");else{r=!1;let y=m.status==="failed_image_pdf"?"Dit PDF bevat scans/afbeeldingen \u2014 maskering niet mogelijk.":m.status==="failed_oversize"?"Bestand is te groot (max 10 MB).":m.status==="failed_ocr"?"OCR kon dit scan-PDF niet verwerken \u2014 probeer later opnieuw.":m.status==="failed_unconfigured"?"Add-on niet correct geconfigureerd.":"Maskering mislukt: "+(m.error||"onbekend");a.setError(p.name,y)}}catch(m){r=!1,a.setError(p.name,m instanceof Error?m.message:"Onbekende fout")}};for(;c.length>0||l.length>0;){for(;l.length<d&&c.length>0;){let p=c.shift(),m=u(p).finally(()=>{let y=l.indexOf(m);y>=0&&l.splice(y,1)});l.push(m)}l.length>0&&await Promise.race(l)}return await a.awaitClose()==="cancel"||!r?null:s}var Qi=["doc","docx","xls","xlsx","ppt","pptx","odt","ods","odp","rtf"],O=!1;function co(){let e=document.getElementById("ai-safety-modal");e&&(e.remove(),O=!1,de())}function ea(e,t){let o=((e||"").toLowerCase().split(".").pop()||"").toLowerCase();return!!(Qi.includes(o)||(t||"").startsWith("application/vnd.openxmlformats")||t==="application/msword"||t==="application/vnd.ms-excel"||t==="application/vnd.ms-powerpoint")}function lo(e,t){return(e||"").toLowerCase().endsWith(".pdf")||t==="application/pdf"}function ta(e,t){return(t||"").startsWith("image/")||/\.(png|jpe?g|gif|webp|bmp|svg)$/i.test(e||"")}function Nt(e,t){let n=[],o=[],i=[];for(let a of Array.from(e||[])){let s=a.name||"",r=a.type||"";if(ta(s,r)){if(t.images_policy==="block"){n.push({file:a,reason:"image"});continue}else if(t.images_policy==="warn"){o.push({file:a,reason:"image"});continue}i.push(a);continue}if(lo(s,r)){if(t.pdfs_policy==="block"){n.push({file:a,reason:"pdf"});continue}else if(t.pdfs_policy==="warn"){o.push({file:a,reason:"pdf"});continue}i.push(a);continue}if(ea(s,r)){if(t.office_policy==="block"){n.push({file:a,reason:"office"});continue}else if(t.office_policy==="warn"){o.push({file:a,reason:"office"});continue}i.push(a);continue}i.push(a)}return{blocked:n,warned:o,allowed:i}}function na(){try{let e=window.__aiDragX??0,t=window.__aiDragY??0,n=document.elementFromPoint?.(e,t),o={bubbles:!0,cancelable:!0,composed:!0};(n??document).dispatchEvent(new DragEvent("dragleave",o)),(n??document).dispatchEvent(new DragEvent("dragend",o)),(n??document).dispatchEvent(new PointerEvent("pointerup",{bubbles:!0,cancelable:!0,composed:!0}))}catch{}}function oa(){try{let e=Array.from(document.querySelectorAll('[role="button"], [data-testid], [class*="drop"], [class*="drag"]'));for(let t of e){let n=t.className||"";/\bdrag|drop|active|highlight/i.test(n)&&t.classList.remove("drag","dragging","drag-active","drop","drop-active","is-dragging","is-drop-active");let o=t.getAttribute("aria-dropeffect");o&&o!=="none"&&t.setAttribute("aria-dropeffect","none"),t.hasAttribute("data-drag-active")&&t.removeAttribute("data-drag-active")}}catch{}}function de(){try{na(),oa()}catch{}}function ao(e){return new Promise(t=>{document.getElementById("ai-safety-modal")?.remove(),O=!0;let n=document.createElement("div");n.id="ai-safety-modal",n.style.zIndex="2147483646";let o=document.createElement("style");o.textContent=`
      @font-face {
        font-family: 'Inter';
        font-style: normal;
        font-weight: 100 900;
        font-display: swap;
        src: url('${chrome.runtime.getURL("fonts/InterVariable.woff2")}') format('woff2-variations');
      }
      #ai-safety-modal {
        position: fixed !important;
        z-index: 2147483646 !important;
        left: 0; top: 0; width: 100vw; height: 100vh;
        background: rgba(0, 0, 0, 0.40);
        display: flex;
        align-items: center;
        justify-content: center;
      }
      #ai-safety-modal-box {
        background: #fff;
        color: #222;
        border-radius: 20px;
        box-shadow: 0 6px 32px rgba(0,0,0,0.16);
        padding: 18px;
        min-width: 340px;
        max-width: 600px;
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
        font-size: 17px;
        position: relative;
        text-align: left;
        overflow: visible;
      }
      #ai-safety-modal-logo {
        margin-bottom: 16px;
        display: flex;
        align-items: center;
        justify-content: flex-start;
      }
      #ai-safety-modal-logo svg {
        height: 42px;
        width: auto;
        margin-left: -10px;
      }
      #ai-safety-modal-close {
        position: absolute; top: 18px; right: 18px; background: transparent; border: none;
        font-size: 26px; color: #888; cursor: pointer; line-height: 1; padding: 0 8px; z-index: 2; transition: color .18s;
      }
      #ai-safety-modal-close:hover { color: #ec4899; }
      #ai-safety-modal h1 {
        font-size: 1.5rem; margin: 0 0 14px 0; color: #505050; letter-spacing: -0.01em; font-weight: 300; font-size
      }
      #ai-safety-modal .ai-safety-modal-desc {
        font-size: 1.06rem; color: #6C6C6C; margin-bottom: 32px; margin-top: 0; font-weight: 300;
      }
      #ai-safety-modal-warning {
        position: relative; background: linear-gradient(90deg,#5b6aee,#ba25ba); border-radius: 16px;
        padding: 26px 16px 22px 16px; box-shadow: 0 1px 5px rgba(255,185,66,0.08);
        display: flex; align-items: center; justify-content: center; overflow: hidden; min-height: 86px;
      }
      #ai-safety-modal-warning .exclam {
        font-size: 42px; color: white; margin: 0px 18px; font-weight: bold; flex-shrink: 0; text-shadow: 0 2px 12px #ffe7a5;
      }
      #ai-safety-modal-warning .warn-text {
        font-size: 1.04rem; color: white; text-align: left; font-weight: 300;
      }
      #ai-safety-modal-btns {
        display: flex; gap: 14px; justify-content: center; margin-top: 32px; margin-bottom: 6px; flex-wrap: wrap;
      }
      #ai-safety-modal-btns button {
        flex: 1 1 160px; min-width: 120px; padding: 12px 10px; font-size: 1rem; font-weight: 300;
        border: none; border-radius: 999px; cursor: pointer; transition: background .18s, box-shadow .16s; margin-bottom: 0; margin-top: 0;
      }
      #ai-safety-modal-btn-ok { background: transparent; color: #252525; border: 1px solid #7C51DC!important; border-radius: 20px; }
      #ai-safety-modal-btn-ok:hover { background-color: #efefef; }
      #ai-safety-modal-btn-more { background: transparent; color: #252525; }
      #ai-safety-modal-btn-more:hover { background-color: #efefef; }
      @media (max-width: 500px) {
        #ai-safety-modal-box { padding: 18px 3vw 6px 3vw; min-width: 0; }
        #ai-safety-modal-warning { flex-direction: column; align-items: flex-start; padding: 16px; }
        #ai-safety-modal-warning .exclam { margin: 0 0 8px 0; }
      }
    `,n.appendChild(o);let i=document.createElement("div");i.id="ai-safety-modal-box",i.setAttribute("role","dialog"),i.setAttribute("aria-modal","true"),i.tabIndex=0;let a=document.createElement("button");a.id="ai-safety-modal-close",a.title="Sluiten",a.setAttribute("aria-label","Sluiten"),a.textContent="\xD7";let s=document.createElement("div");s.id="ai-safety-modal-logo",s.innerHTML=`
      <svg id="Laag_1" data-name="Laag 1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 699.1 171.67">
        <defs>
          <style>
            .cls-1 { letter-spacing: 0em; }
            .cls-1, .cls-2, .cls-3, .cls-4, .cls-5 { fill: #402bbc; }
            .cls-6 { fill: url(#Naamloos_verloop_2577); }
            .cls-7 { fill: url(#Naamloos_verloop_2413); }
            .cls-2 { letter-spacing: -.04em; }
            .cls-8 { fill: #32109b; letter-spacing: 0em; }
            .cls-3 { letter-spacing: 0em; }
            .cls-4 { letter-spacing: .02em; }
            .cls-5 { letter-spacing: 0em; }
            .cls-9 { fill: url(#Naamloos_verloop_2413-2); }
            .cls-10 { fill: #ba24ba; letter-spacing: .02em; }
            .cls-11 { font-family: AvenirNext-Bold, 'Avenir Next'; font-size: 68.71px; font-weight: 700; }
          </style>
          <linearGradient id="Naamloos_verloop_2577" data-name="Naamloos verloop 2577" x1="76.17" y1="89.78" x2="172.31" y2="89.78" gradientUnits="userSpaceOnUse">
            <stop offset="0" stop-color="#06cbd9"/>
            <stop offset=".16" stop-color="#16b8dd"/>
            <stop offset=".73" stop-color="#4b7aea"/>
            <stop offset="1" stop-color="#6062f0"/>
          </linearGradient>
          <linearGradient id="Naamloos_verloop_2413" data-name="Naamloos verloop 2413" x1="40.31" y1="79.45" x2="138.42" y2="79.45" gradientUnits="userSpaceOnUse">
            <stop offset="0" stop-color="#3e31f3"/>
            <stop offset=".81" stop-color="#ea34bb"/>
            <stop offset="1" stop-color="#ff0dbb"/>
          </linearGradient>
          <linearGradient id="Naamloos_verloop_2413-2" data-name="Naamloos verloop 2413" x1="144.88" y1="105.71" x2="180.28" y2="105.71" xlink:href="#Naamloos_verloop_2413"/>
        </defs>
        <path class="cls-6" d="M155.08,52.27c3.59-1,16.96,12.46,17.21,15.06.09.98-.08,1.89-.61,2.73l-56.98,56.45c-.77.41-1.63.84-2.52.81-2.91-.08-31.17-30.62-35.63-35.13-2.97-3.76,12.52-17.46,14.38-17.66,6.51-.68,18.98,18.5,22.25,17.92l41.91-40.18Z"/>
        <g>
          <path class="cls-7" d="M123,76.08l15.41-14.28c-9.66-11.26-17.82-20.75-20.15-23.48-2-2.33-4.89-3.66-7.97-3.66s-5.96,1.33-7.97,3.66c-3.38,3.93-18.88,21.99-33.54,39.07-7.33,8.54-14.45,16.83-19.74,22.99-2.64,3.08-4.83,5.62-6.35,7.4-.76.89-1.36,1.58-1.77,2.06-.41.47-.62.72-.62.73l15.93,13.68s36.86-42.94,54.05-62.96c3.56,4.15,7.96,9.27,12.71,14.8Z"/>
          <path class="cls-9" d="M160.21,87.18l-15.32,14.39c10.84,12.63,19.46,22.67,19.46,22.67l15.93-13.68s-8.94-10.42-20.07-23.39Z"/>
        </g>
        <text class="cls-11" transform="translate(218.33 109.62)"><tspan class="cls-4" x="0" y="0">SAFE</tspan><tspan class="cls-1" x="177.48" y="0"> </tspan><tspan class="cls-10" x="194.79" y="0">AI</tspan><tspan class="cls-8" x="269.48" y="0"> </tspan><tspan class="cls-5" x="287.21" y="0">W</tspan><tspan class="cls-2" x="358.19" y="0">A</tspan><tspan class="cls-3" x="405.53" y="0">Y</tspan></text>
      </svg>
    `;let r=document.createElement("h1");r.textContent="Je staat op het punt een document te delen met een AI-systeem.";let c=document.createElement("div");c.className="ai-safety-modal-desc",c.innerHTML="Neem even de tijd om na te denken of dit bestand persoonlijke of gevoelige gegevens bevat zoals: <br />namen, adressen, foto's, vertrouwelijke informatie.";let l=document.createElement("div");l.id="ai-safety-modal-warning",l.innerHTML=`
      <span class="exclam">!</span>
      <span class="warn-text">AI-systemen kunnen data gebruiken om te leren, dus deel enkel wat veilig en anoniem mag zijn.</span>
    `;let d=document.createElement("div");d.id="ai-safety-modal-btns";let u=document.createElement("button");u.id="ai-safety-modal-btn-ok",u.autofocus=!0,u.textContent="Ok, ik begrijp het",d.appendChild(u),i.appendChild(a),i.appendChild(s),i.appendChild(r),i.appendChild(c),i.appendChild(l),i.appendChild(d),n.appendChild(i),document.documentElement.appendChild(n),setTimeout(()=>i.focus(),0);let f=()=>{n.remove(),O=!1,de()};n.addEventListener("click",p=>{p.target===n&&(f(),t(!1))}),a.addEventListener("click",()=>{f(),t(!1)}),document.addEventListener("keydown",function(m){m.key==="Escape"&&(m.stopPropagation(),f(),t(!1))},{capture:!0,once:!0}),u.addEventListener("click",()=>{let p=!!e.isWarning;f(),t(p)})})}async function qe(e,t){if(!t.enabled)return"allow";let{blocked:n,warned:o,allowed:i}=Nt(e,t),a=n.length>0,s=o.length>0;if(a){let r=new Map;for(let{reason:l}of n)r.set(l,(r.get(l)||0)+1);let c=window.location.hostname;for(let[l,d]of r.entries())Pn(l,d,c).catch(()=>{})}return a?(ao({isWarning:!1,blocked:n,allowedCount:i.length+o.length}).catch(()=>{}),"blocked"):s?await ao({isWarning:!0,blocked:o,allowedCount:i.length})?"warn-allow":"warn-deny":"allow"}function Dt(e,t){!(e instanceof HTMLInputElement)||e.type!=="file"||e.__sawBoundFiles||(e.__sawBoundFiles=!0,e.addEventListener("change",async n=>{let o=t();if(!o.enabled)return;let i=Array.from(e.files||[]);if(!i.length||so(i))return;if(O){e.value="";try{n.stopImmediatePropagation?.()}catch{}try{n.stopPropagation?.()}catch{}e.dispatchEvent(new Event("input",{bubbles:!0})),e.dispatchEvent(new Event("change",{bubbles:!0}));return}let{blocked:a}=Nt(i,o),s=Rt(i,o);if(a.length===0&&s.length>0){try{n.stopImmediatePropagation?.()}catch{}try{n.stopPropagation?.()}catch{}let c=window.location.hostname,l=await ro(i,o,c);if(l&&l.size>0){let d=i.map(u=>l.get(u)??u);Bt(e,d);return}}let r=await qe(i,o);if(!(r==="allow"||r==="warn-allow")){e.value="";try{n.stopImmediatePropagation?.()}catch{}try{n.stopPropagation?.()}catch{}e.dispatchEvent(new Event("input",{bubbles:!0})),e.dispatchEvent(new Event("change",{bubbles:!0}))}},{capture:!0}))}function Pt(e,t){e.querySelectorAll?.('input[type="file"]').forEach(n=>Dt(n,t))}function Ve(e,t){e.matches?.('input[type="file"]')&&Dt(e,t),e.querySelectorAll?.('input[type="file"]').forEach(n=>Dt(n,t))}function uo(e){window.addEventListener("dragenter",t=>{e().enabled&&O&&(t.preventDefault(),t.stopPropagation())},{capture:!0}),window.addEventListener("dragover",t=>{e().enabled&&(window.__aiDragX=t.clientX,window.__aiDragY=t.clientY,O&&(t.preventDefault(),t.stopPropagation()))},{capture:!0}),window.addEventListener("dragleave",t=>{e().enabled&&O&&(t.preventDefault(),t.stopPropagation())},{capture:!0}),window.addEventListener("drop",async t=>{let n=e();if(!n.enabled)return;if(O){t.preventDefault(),t.stopPropagation(),de();return}let o=t.dataTransfer;if(!o)return;let i=Array.from(o.files||[]);if(!i.length||so(i))return;let{blocked:a}=Nt(i,n),s=Rt(i,n);if(a.length===0&&s.length>0){let c=t.target;t.preventDefault(),t.stopPropagation();let l=window.location.hostname,d=await ro(i,n,l);if(d&&d.size>0){let f=i.map(p=>d.get(p)??p);Qn(l)?await io({files:f,reason:"Deze site (Gemini) ondersteunt geen automatische drag-and-drop voor gesaneerde bestanden. Download het hieronder en upload via de + knop.",onDownload:eo}):no(c,f).delivered,de();return}let u=await qe(i,n);de();return}let r=await qe(i,n);r==="allow"||r==="warn-allow"||(t.preventDefault(),t.stopPropagation(),de())},{capture:!0}),window.addEventListener("paste",async t=>{let n=e();if(!n.enabled)return;if(O){t.preventDefault(),t.stopPropagation();return}let o=Array.from(t.clipboardData?.items||[]),i=[];for(let s of o)if(s.kind==="file"){let r=s.getAsFile();r&&i.push(r)}if(!i.length)return;let a=await qe(i,n);a==="allow"||a==="warn-allow"||(t.preventDefault(),t.stopPropagation())},{capture:!0})}function Ee(e,t){e.querySelectorAll?.("input, textarea, [contenteditable=''], [contenteditable='true'], [contenteditable='plaintext-only']").forEach(t),e.querySelectorAll?.("[contenteditable]").forEach(n=>{let o=n.getAttribute("contenteditable");o&&o!=="false"&&o!=="inherit"&&t(n)})}function Xe(e,t,n){new MutationObserver(i=>{for(let a of i)if(a.addedNodes.forEach(s=>{if(s.nodeType===Node.ELEMENT_NODE){let r=s;(We(r)||j(r))&&t(r),r.querySelectorAll?.("input, textarea, [contenteditable=''], [contenteditable='true'], [contenteditable='plaintext-only']").forEach(t),r.querySelectorAll?.("[contenteditable]").forEach(c=>{let l=c.getAttribute("contenteditable");l&&l!=="false"&&l!=="inherit"&&t(c)}),n&&n(r)}}),a.type==="attributes"&&a.target.nodeType===Node.ELEMENT_NODE){let s=a.target;a.attributeName==="contenteditable"&&j(s)&&t(s)}}).observe(e,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["contenteditable"]})}function mo(e,t,n,o){if(!(We(e)||j(e))||ve(e)||e.__sawBound)return;e.__sawBound=!0,e.addEventListener("input",()=>t(e),{passive:!0,capture:!0}),e.addEventListener("keyup",s=>{let c=s.key;(c===" "||c==="Backspace"||c==="Delete"||c==="Enter"||c==="Tab"||c.length===1)&&t(e)},{capture:!0}),e.addEventListener("paste",s=>n(e,s));let a=e.closest?.("form");a&&!At(a)&&a.addEventListener("submit",()=>{o().enabled&&a.querySelectorAll("input, textarea, [contenteditable=''], [contenteditable='true']").forEach(r=>t(r))},!0)}function po(e,t){window.addEventListener("paste",n=>{let o=n,i=n.composedPath?n.composedPath()[0]:n.target,a=e(i);a&&t(a,o)},!0)}var fo=new WeakSet;function Je(e,t,n,o){let i=e.querySelectorAll("*");for(let a=0;a<i.length;a++){let r=i[a].shadowRoot;r&&!fo.has(r)&&(fo.add(r),Ee(r,t),Xe(r,t,o),n&&r.addEventListener("paste",c=>{let l=c,d=c.composedPath?c.composedPath()[0]:c.target,u=we(d);u&&n(u,l)},!0),Je(r,t,n,o))}}function go(e,t,n,o,i){let a=Element.prototype.attachShadow;a&&(Element.prototype.attachShadow=function(s){let r=a.call(this,s);return e(r,n),t(r,n),r.addEventListener?.("paste",c=>{let l=c,d=c.composedPath?c.composedPath()[0]:c.target,u=we(d);u&&o(u,l)},!0),i&&i(r),r})}dt();ye();Re();G();_t();G();var Qe=new Map,et=new WeakMap;function Ht(){return`N-${Date.now()}-${Math.random().toString(36).slice(2,7)}`}function Ft(e){let t=(typeof window<"u"?window:globalThis).setTimeout(()=>{X(e.nudgeId,"ignored")},6e4),n={nudgeId:e.nudgeId,displayedAt:Date.now(),piiTypes:e.piiTypes,piiCount:e.piiCount,matchTexts:e.matchTexts,element:e.element,timeoutId:t,responded:!1};Qe.set(e.nudgeId,n);let o=et.get(e.element);return o||(o=new Set,et.set(e.element,o)),o.add(e.nudgeId),e.nudgeId}function X(e,t,n){let o=Qe.get(e);if(!o||o.responded)return;o.responded=!0,clearTimeout(o.timeoutId);let i=Date.now()-o.displayedAt,a=0;if(n!==void 0)a=Math.max(0,o.piiCount-n);else{let c=bo(o.element);c!==null&&(a=o.matchTexts.filter(l=>c.includes(l)).length)}let s=n??o.piiCount-a;jn({nudgeId:e,responseType:t,responseTimeMs:i,piiRemovedCount:Math.max(0,s),piiRemainingCount:a,hostname:typeof window<"u"?window.location.hostname:""}).catch(()=>{}),Qe.delete(e);let r=et.get(o.element);r&&r.delete(e)}function ho(e){let t=et.get(e);if(!t||t.size===0)return;let n=bo(e);if(n!==null)for(let o of[...t]){let i=Qe.get(o);if(!i||i.responded)continue;let a=i.matchTexts.filter(s=>n.includes(s));if(a.length<i.matchTexts.length){let s=i.matchTexts.length-a.length;X(o,"adjusted",s)}}}function bo(e){return e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement?e.value:e.isContentEditable?e.textContent||e.innerText||"":null}var U=new WeakMap,Ut=new WeakMap,nt=new Set,Wt=new WeakMap,yo=new WeakMap,J=new WeakMap;function ia(){return typeof window<"u"?window.location.hostname:""}function aa(e,t){return t.some(n=>n.type===e.type&&e.start<n.end&&e.end>n.start)}var sa=`
  /* Container for the highlight backdrop (behind input/textarea) */
  .ai-safety-highlight-container {
    position: absolute;
    pointer-events: none;
    overflow: hidden;
    z-index: 0;
  }

  /* Overlay variant for contenteditable: sits ON TOP of the element */
  .ai-safety-highlight-container.ai-safety-highlight-overlay {
    z-index: 2147483646;
  }

  /* The backdrop that shows highlighted text */
  .ai-safety-highlight-backdrop {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    white-space: pre-wrap;
    word-wrap: break-word;
    overflow-wrap: break-word;
    color: transparent;
    pointer-events: none;
  }

  /* The actual highlight mark - uses selection-like blue color */
  .ai-safety-highlight-backdrop mark {
    color: transparent;
    background-color: rgba(51, 153, 255, 0.4);
    border-radius: 2px;
    box-shadow: 0 0 0 1px rgba(30, 120, 220, 0.3);
    animation: ai-safety-mark-pulse 1.5s ease-in-out infinite;
  }

  @keyframes ai-safety-mark-pulse {
    0%, 100% {
      background-color: rgba(51, 153, 255, 0.4);
      box-shadow: 0 0 0 1px rgba(30, 120, 220, 0.3);
    }
    50% {
      background-color: rgba(51, 153, 255, 0.6);
      box-shadow: 0 0 0 2px rgba(30, 120, 220, 0.5);
    }
  }
`,jt=!1;function ra(){if(jt)return;if(document.getElementById("ai-safety-learnmate-styles")){jt=!0;return}jt=!0;let e=document.createElement("style");e.id="ai-safety-learnmate-styles",e.textContent=sa,document.documentElement.appendChild(e)}function ca(e){let t=le[e.type]||"gevoelige gegevens",n=Ke[e.type]||"",o=e.text.length>30?e.text.slice(0,27)+"...":e.text,i=n?`Wil je deze informatie verbergen?<br><br>${n}`:"Wil je deze informatie verbergen?";return{message:`Ik heb een <strong>${t}</strong> gedetecteerd:<br><code style="background: rgba(51,153,255,0.3); padding: 2px 6px; border-radius: 3px; font-size: 12px;">${da(o)}</code>`,detail:i}}function la(e){let t=new Map;for(let i of e)t.set(i.type,(t.get(i.type)||0)+1);let n=[];for(let[i,a]of t.entries()){let s=le[i]||"gevoelige gegevens";a>1?n.push(`${a}x ${s}`):n.push(s)}let o=n.map(i=>`\u2022 ${i}`).join("<br>");return{message:`Ik heb <strong>${e.length} gevoelige items</strong> gedetecteerd:<br>${o}`,detail:"Wil je al deze informatie verbergen?"}}function da(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}var ua=3;function ke(e,t,n,o=!1){let i=yo.get(e);i&&window.clearTimeout(i);let a=o?50:100,s=window.setTimeout(()=>{fa(e,t,n,o)},a);yo.set(e,s)}function fa(e,t,n,o=!1){let i;if(e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement)i=e.value;else if(e.isContentEditable)i=e.innerText||e.textContent||"";else return;ue(e);let s=re(i,t),r=Wn(e);if(r.length>0&&(s.matches=s.matches.filter(f=>f.type!=="crisis"?!0:!r.some(p=>p.text.toLowerCase()===f.text.toLowerCase()&&Math.abs(p.start-f.start)<30))),s.matches.length===0){U.delete(e);return}U.set(e,{matches:s.matches,originalText:i}),Eo=t,vo(e,s.matches);let c=J.get(e);c||(c=[],J.set(e,c));let l=s.matches.filter(f=>!aa(f,c));if(l.length===0)return;for(let f of l)c.push({type:f.type,start:f.start,end:f.end});let d=i.length,u=ia();if(o&&l.length>=ua){let{message:f,detail:p}=la(l),m=Ht(),y=[...new Set(l.map(h=>h.type))],x=l.map(h=>h.text);Ct({nudgeId:m,piiTypesDetected:y,piiCount:l.length,promptLengthChars:d,hostname:u}).catch(()=>{}),Ft({nudgeId:m,piiTypes:y,piiCount:l.length,matchTexts:x,element:e}),gt(t.profile,f,p,()=>{X(m,"clicked_hide",l.length),pa(e,t),n()},"Verberg allemaal",()=>{X(m,"dismissed")},void 0)}else for(let f of l){let{message:p,detail:m}=ca(f),y=Ht();Ct({nudgeId:y,piiTypesDetected:[f.type],piiCount:1,promptLengthChars:d,hostname:u}).catch(()=>{}),Ft({nudgeId:y,piiTypes:[f.type],piiCount:1,matchTexts:[f.text],element:e}),gt(t.profile,p,m,()=>{X(y,"clicked_hide",1),ma(e,f,t),n()},"Verbergen",()=>{X(y,"dismissed")},void 0)}}function vo(e,t){ra();let n=e,o=e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement;ue(e);let i;if(o)i=e.value;else if(n.isContentEditable)i=n.innerText||n.textContent||"";else return;if(t.length===0)return;let a=document.createElement("div");a.className="ai-safety-highlight-container",o||a.classList.add("ai-safety-highlight-overlay");let s=document.createElement("div");s.className="ai-safety-highlight-backdrop",a.appendChild(s);let r=window.getComputedStyle(n),c=["fontFamily","fontSize","fontWeight","fontStyle","letterSpacing","wordSpacing","textTransform","lineHeight","textAlign","textIndent","paddingTop","paddingRight","paddingBottom","paddingLeft","borderTopWidth","borderRightWidth","borderBottomWidth","borderLeftWidth"];for(let p of c)s.style[p]=r[p];s.innerHTML=xo(i,t),document.body.appendChild(a),Ot(n,a,r);let l=n.style.backgroundColor||"";o&&(n.style.backgroundColor="transparent");let d=()=>{o&&e instanceof HTMLTextAreaElement&&(s.scrollTop=e.scrollTop,s.scrollLeft=e.scrollLeft),Ot(n,a,r)},u=()=>{if(ho(e),U.get(e)){let m;o?m=e.value:m=n.innerText||n.textContent||"";let y=re(m,Eo);y.matches.length>0?(s.innerHTML=xo(m,y.matches),U.set(e,{matches:y.matches,originalText:m})):(ue(e),U.delete(e))}};e.addEventListener("input",u,{passive:!0}),o&&e.addEventListener("scroll",d,{passive:!0}),window.addEventListener("scroll",d,{passive:!0,capture:!0}),window.addEventListener("resize",d,{passive:!0});let f=new ResizeObserver(()=>{Ot(n,a,r)});f.observe(e),Wt.set(e,f),Ut.set(e,{container:a,backdrop:s,originalBackground:l,scrollHandler:d,inputHandler:u}),nt.add(e)}function xo(e,t){if(t.length===0)return tt(e);let n=[...t].sort((a,s)=>a.start-s.start),o="",i=0;for(let a of n)a.start<i||(a.start>i&&(o+=tt(e.slice(i,a.start))),o+=`<mark>${tt(a.text)}</mark>`,i=a.end);return i<e.length&&(o+=tt(e.slice(i))),o}function tt(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;").replace(/\n/g,"<br>")}function Ot(e,t,n){let o=e.getBoundingClientRect(),i=window.scrollX||window.pageXOffset,a=window.scrollY||window.pageYOffset,s=parseFloat(n.borderTopWidth)||0,r=parseFloat(n.borderLeftWidth)||0;t.style.left=`${o.left+i+r}px`,t.style.top=`${o.top+a+s}px`,t.style.width=`${o.width-r-(parseFloat(n.borderRightWidth)||0)}px`,t.style.height=`${o.height-s-(parseFloat(n.borderBottomWidth)||0)}px`}var Eo=null;function ue(e){let t=Ut.get(e);if(t){let{container:o,originalBackground:i,scrollHandler:a,inputHandler:s}=t,r=e,c=e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement;c&&(r.style.backgroundColor=i),e.removeEventListener("input",s),c&&e.removeEventListener("scroll",a),window.removeEventListener("scroll",a,{capture:!0}),window.removeEventListener("resize",a),o.remove(),Ut.delete(e),nt.delete(e)}let n=Wt.get(e);n&&(n.disconnect(),Wt.delete(e))}function ma(e,t,n){let o;if(e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement)o=e.value;else if(e.isContentEditable)o=e.innerText||e.textContent||"";else return;let a=re(o,n).matches.find(c=>c.text===t.text&&c.type===t.type&&Math.abs(c.start-t.start)<50);if(!a){wo(e,n);return}let s=o.slice(0,a.start)+a.replacement+o.slice(a.end);if(e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement){let c=e.selectionStart??e.value.length;e.value=s;let l=Math.min(c,s.length);try{e.setSelectionRange(l,l)}catch{}e.dispatchEvent(new Event("input",{bubbles:!0}))}else e.isContentEditable&&(e.textContent=s,e.dispatchEvent(new Event("input",{bubbles:!0})));V(a.type,1,window.location.hostname).catch(()=>{});let r=J.get(e);if(r){let c=r.filter(l=>!(l.type===t.type&&t.start<l.end&&t.end>l.start));J.set(e,c)}wo(e,n)}function pa(e,t){let n;if(e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement)n=e.value;else if(e.isContentEditable)n=e.innerText||e.textContent||"";else return;ue(e);let o=re(n,t);if(o.matches.length===0){U.delete(e),J.delete(e);return}let i=n,a=[...o.matches].sort((r,c)=>c.start-r.start);for(let r of a)i=i.slice(0,r.start)+r.replacement+i.slice(r.end);if(e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement){let r=e.selectionStart??e.value.length;e.value=i;let c=Math.min(r,i.length);try{e.setSelectionRange(c,c)}catch{}e.dispatchEvent(new Event("input",{bubbles:!0}))}else e.isContentEditable&&(e.textContent=i,e.dispatchEvent(new Event("input",{bubbles:!0})));let s=window.location.hostname;for(let r of o.types){let c=o.matches.filter(l=>l.type===r).length;V(r,c,s).catch(()=>{})}U.delete(e),J.delete(e)}function wo(e,t){let n;if(e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement)n=e.value;else if(e.isContentEditable)n=e.innerText||e.textContent||"";else return;ue(e);let o=re(n,t);if(o.matches.length===0){U.delete(e),J.delete(e);return}U.set(e,{matches:o.matches,originalText:n}),vo(e,o.matches)}function ko(){for(let n of nt)ue(n);nt.clear(),document.querySelectorAll(".ai-safety-highlight-container").forEach(n=>n.remove()),document.querySelectorAll("input, textarea").forEach(n=>{let o=n;o.style.backgroundColor==="transparent"&&(o.style.backgroundColor="")})}var b={..._e},H=R(b,b.profile),an=!1,lt=0,dn=250,rn=!0,ii=!1;function Ga(){return new Promise(e=>{try{let t=F?.storage?.local;if(!t){e(!1);return}t.get("orgId",n=>{e(!!n?.orgId)})}catch{e(!1)}})}function qa(){if(!b.whitelist||b.whitelist.length===0)return!1;let t=window.location.hostname.toLowerCase().replace(/^www\./i,"");return b.whitelist.some(n=>{let o=n.toLowerCase().replace(/^www\./i,"");return t===o||t.endsWith("."+o)})}function Va(){let e=window.location.hostname.toLowerCase(),t=window.location.pathname.toLowerCase();return wt(e)||vt(e,t)}function ni(){b.enabled&&b.profile!=="safemate"&&Va()&&kn(b.profile,Xa)}function Xa(){let t={...b,profile:"safemate",...{mask_email:!0,mask_phone:!0,mask_cc:!0,mask_iban:!0,mask_natid:!0,mask_address:!0,mask_dob_age:!0,mask_children:!0,mask_health:!0,mask_crisis:!0,images_policy:"warn",pdfs_policy:"warn",office_policy:"warn",visual_replace_on_send:!0,block_jailbreak:!0,crisis_detect:!0}};si(t);try{$()?.set?.({[ie]:t})}catch{}try{F.runtime?.sendMessage?.({type:"SWITCH_PROFILE",profile:"safemate"})}catch{}}function cn(e){if(!b.blocklist||b.blocklist.length===0)return!1;let t=e.toLowerCase().replace(/^www\./i,"");return b.blocklist.some(n=>{let o=n.toLowerCase().replace(/^www\./i,"");return t===o||t.endsWith("."+o)})}function Ja(){return cn(window.location.hostname)}function ai(){if(!b.enabled||!Ja())return;let e=b.profile==="blokkeren"||b.profile==="aangepast"||b.profile==="classmate";if(!(ii||e))return;let t="https://www.safeaiway.com/",n=b.redirect_url||t,o="";try{o=new URL(n).hostname}catch{}if(!o||cn(o)){let i="";try{i=new URL(t).hostname}catch{}if(!i||cn(i))return;window.location.href=t;return}o.toLowerCase().replace(/^www\./i,"")!==window.location.hostname.toLowerCase().replace(/^www\./i,"")&&(window.location.href=n)}function I(){return rn?b.enabled&&!qa():!1}function ln(){return b.profile||"aangepast"}function Qa(e){if(!I())return e;let t=An(e,b);if(t.sanitizationCounts.size>0){let n=window.location.hostname,o=b.profile==="learnmate"?"warned":"masked";for(let[a,s]of t.sanitizationCounts.entries())V(a,s,n).catch(()=>{}),Promise.resolve().then(()=>(ti(),ei)).then(({queueAuditEvent:r})=>{r(a,o,n).catch(()=>{})}).catch(()=>{});let i=b.profile;if(i){let a=Array.from(t.sanitizationCounts.keys());if(a.length===1){let{message:s,detail:r}=Mt(a[0],i);se({message:s,detail:r,profile:i})}else{let r=`Ik heb volgende info verborgen:<br>${a.map(c=>`\u2022 ${zt(c)}`).join("<br>")}<br><br>Deze informatie slaat AI op voor trainingsdoeleinden.`;se({message:r,profile:i})}}}return t.text}function un(){return b.profile==="learnmate"}function es(e){if(!I())return;let t=e.value??"",n=un();if(Tt(e,t,I(),b.crisis_detect,n,()=>{H=R(b,b.profile)}),St(t,I(),b.block_jailbreak),n){if(Date.now()-lt<dn)return;ke(e,b,()=>{H=R(b,b.profile)});return}Gn(e,H)}function ts(e){if(!I())return;let t=e.innerText||e.textContent||"",n=un();if(Tt(e,t,I(),b.crisis_detect,n,()=>{H=R(b,b.profile)}),St(t,I(),b.block_jailbreak),n){if(Date.now()-lt<dn)return;ke(e,b,()=>{H=R(b,b.profile)});return}Yn(e,H)}function ns(e){I()&&(ve(e)||(e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement?es(e):j(e)&&ts(e)))}function Se(e,t){if(an||!I()||ve(e))return;let n=t.clipboardData;if(!n)return;let o=n.getData("text/plain")||n.getData("text")||"";if(!o)return;if(un()){let a=Date.now();if(a-lt<dn)return;lt=a,setTimeout(()=>{e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement?ke(e,b,()=>{H=R(b,b.profile)},!0):j(e)&&ke(e,b,()=>{H=R(b,b.profile)},!0)},10);return}let i=Qa(o);if(i!==o)if(t.preventDefault(),t.stopImmediatePropagation?.(),an=!0,queueMicrotask(()=>{an=!1}),e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement){let a=e.selectionStart??e.value.length,s=e.selectionEnd??e.value.length,r=e.value.slice(0,a),c=e.value.slice(s);e.value=r+i+c;let l=r.length+i.length;e.setSelectionRange(l,l),e.dispatchEvent(new Event("input",{bubbles:!0})),e.dispatchEvent(new Event("change",{bubbles:!0}))}else j(e)&&($n(i),e.dispatchEvent(new Event("input",{bubbles:!0})))}function ge(e){mo(e,ns,Se,oe)}var sn=null,ct=null;function os(e){ct=e,sn===null&&(sn=setTimeout(()=>{sn=null,ct&&(si(ct),ct=null)},50))}function si(e){let t=b.profile==="learnmate";b=Object.assign({},b,e),H=R(b,b.profile),t&&b.profile!=="learnmate"&&ko(),ai(),co(),Be({enabled:I(),badgeProfile:ln()})}function oe(){return{enabled:I(),images_policy:b.images_policy,pdfs_policy:b.pdfs_policy,office_policy:b.office_policy,addons:b.addons}}var oi="__saw_content_initialized__";if(!globalThis[oi]){globalThis[oi]=!0;try{document.dispatchEvent(new CustomEvent("__saw-content-injected"))}catch{}(async function(){let t=await Ga();if(ii=t,!t){let i=window.location.hostname.toLowerCase(),a=window.location.pathname.toLowerCase();if(!wt(i)&&!vt(i,a))return}let n=await gn();n&&typeof n.isActive=="boolean"&&(rn=n.isActive),b=await pn(),H=R(b,b.profile),ai(),Ee(document,ge),Xe(document,ge,i=>Ve(i,oe)),Je(document,ge,Se,i=>Ve(i,oe)),Pt(document,oe),po(we,Se),uo(oe),go(Ee,Xe,ge,Se,i=>Pt(i,oe)),Be({enabled:I(),badgeProfile:ln()}),setTimeout(()=>{pt(),ni()},1500),hn(os,i=>{rn=i.isActive,Be({enabled:I(),badgeProfile:ln()})});let o=0;setInterval(()=>{o++,pt()&&(Cn(),ni()),o%2===0&&(Ee(document,ge),Je(document,ge,Se,a=>Ve(a,oe)))},5e3)})()}})();
/*! Bundled license information:

@noble/ed25519/index.js:
  (*! noble-ed25519 - MIT License (c) 2019 Paul Miller (paulmillr.com) *)
*/
