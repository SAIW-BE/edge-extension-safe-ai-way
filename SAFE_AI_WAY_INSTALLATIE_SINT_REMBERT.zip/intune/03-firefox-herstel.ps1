# Safe AI Way - Firefox, herstel voor een Intune-remediatie.
#
#   Run this script using the logged on credentials : Nee
#   Run script in 64 bit PowerShell host            : Ja
#
# LET OP: dit OVERSCHRIJFT policies.json. Heb je daar ander Firefox-beleid in
# staan, gebruik dit script dan niet maar voeg onze twee blokken toe aan je
# eigen bestand.

$json = @'
{
  "policies": {
    "ExtensionSettings": {
      "info@safeaiway.com": {
        "installation_mode": "force_installed",
        "install_url": "https://saiw-be.github.io/firefox-extension-safe-ai-way/safe-ai-way-firefox-v2.3.0.xpi",
        "updates_disabled": false
      }
    },
    "3rdparty": {
      "Extensions": {
        "info@safeaiway.com": {
          "enrollmentToken": "org_REMBERT02",
          "deploymentFlavor": "school"
        }
      }
    }
  }
}
'@

$ErrorActionPreference = "Stop"

$mappen = @(@(
  "$env:SystemDrive\Program Files\Mozilla Firefox",
  "$env:SystemDrive\Program Files (x86)\Mozilla Firefox"
) | Select-Object -Unique | Where-Object { Test-Path $_ })

foreach ($map in $mappen) {
  $doel = Join-Path $map "distribution"
  New-Item -ItemType Directory -Path $doel -Force | Out-Null
  # Set-Content -Encoding UTF8 schrijft in Windows PowerShell een BOM, en daar
  # kan Firefox op struikelen. Dit schrijft UTF-8 zonder BOM.
  [System.IO.File]::WriteAllText(
    (Join-Path $doel "policies.json"), $json,
    (New-Object System.Text.UTF8Encoding($false)))
  Write-Output "policies.json geschreven in $doel"
}
